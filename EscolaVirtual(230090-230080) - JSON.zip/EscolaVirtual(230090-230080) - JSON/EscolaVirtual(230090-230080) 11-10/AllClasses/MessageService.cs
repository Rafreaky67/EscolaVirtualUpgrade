﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public static class MessageService
    {
        private static List<Message> m_Messages = new List<Message>();

        public static void SendMessage(Message msg)
        {
            m_Messages.Add(msg);
        }

        public static List<Message> GetMessages() { return m_Messages; }
        public static int GetNonRead(User receiver, User sender) {
            return m_Messages.Count(p => p.GetReceiver() == receiver &&
            p.GetSender() == sender && p.GetReadStatus() == false); }
        public static void CheckRead(User receiver, User sender) 
        {
            foreach (Message message in m_Messages.Where(p => p.GetReceiver() == receiver && p.GetSender() == sender))
                message.SetReadStatus(true);
        }
    }
}
