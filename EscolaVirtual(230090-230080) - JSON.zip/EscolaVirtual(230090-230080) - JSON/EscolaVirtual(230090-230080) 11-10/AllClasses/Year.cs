﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Year
    {
        string m_Year { get; set; }
        List<Class> m_Class { get; set; }
        List<Subject> m_Subjects { get; set; }

        public Year(string year, List<Class> classes, List<Subject> subjects)
        {
            m_Year = year;
            m_Class = classes;
            m_Subjects = subjects;
        }

        public bool AddClass(Class newclass)
        {
            if (m_Class != null)
            {
                if (m_Class.Contains(newclass))
                    return false;
                else
                {
                    m_Class.Add(newclass);
                    return true;
                }
            }
            else
            {
                m_Class.Add(newclass);
                return true;
            }
        }

        public bool RemoveClass(Class removeclass)
        {
            if (m_Class.Contains(removeclass))
            {
                m_Class.Remove(removeclass);
                return true;
            }
            else
                return false;
        }

        public bool AddSubject(Subject newsubject)
        {
            if (m_Subjects != null)
            {
                if (m_Subjects.Contains(newsubject))
                    return false;
                else
                {
                    m_Subjects.Add(newsubject);
                    return true;
                }
            }
            else
            {
                m_Subjects.Add(newsubject);
                return true;
            }
        }

        public bool RemoveSubject(Subject removesubject)
        {
            if (m_Subjects.Contains(removesubject))
            {
                m_Subjects.Remove(removesubject);
                return true;
            }
            else
                return false;
        }

        public string GetYear() { return m_Year; }
        public void SetYear(string year) { m_Year = year; }
        public List<Class> GetClasses() { return m_Class; }
        public void SetClasses(List<Class> classes) { m_Class = classes; }
        public List<Subject> GetSubjects() { return m_Subjects; }
        public void SetSubjects(List<Subject> subjects) { m_Subjects = subjects; }

    }
}
