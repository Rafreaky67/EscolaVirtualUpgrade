﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class User
    {
        string m_Login { get; set; }
        string m_Password { get; set; }
        string m_Name { get; set; }

        public User(string login, string pass, string name)
        {
            m_Login = login;
            m_Password = pass;
            m_Name = name;
        }

        public string GetLogin() { return m_Login; }
        public void SetLogin(string login) { m_Login = login; }
        public string GetPassword() { return m_Password; }
        public void SetPassword(string password) { m_Password = password; }
        public string GetName() { return m_Name; }
        public void SetName(string name) { m_Name = name; }
    }
}
