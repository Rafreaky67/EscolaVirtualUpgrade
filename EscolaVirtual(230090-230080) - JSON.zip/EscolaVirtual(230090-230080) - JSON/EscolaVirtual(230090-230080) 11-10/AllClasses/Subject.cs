﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Subject
    {
        string m_Name { get; set; }
        string m_Teacher { get; set; }

        public Subject(string name, string teacher)
        {
            m_Name = name;
            m_Teacher = teacher;
        }

        public string GetName() { return m_Name; }
        public void SetName(string name) { m_Name = name; }
        public string GetTeacher() { return m_Teacher; }
        public void SetTeacher(string teacher) { m_Teacher = teacher; }
    }
}
