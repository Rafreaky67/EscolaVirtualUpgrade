﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Card
    {
         internal double m_balance { get; set; }

        public Card(double balance)
        { 
            m_balance = balance;
        }

        public double GetBalance() { return m_balance; }
        public void SetBalance(double balance) { m_balance = balance; }
        public bool Deposit(double value) 
        {
            if (value <= 0)
                return false;
            else
            {
                m_balance += value;
                return true;
            }
        }
    }
}