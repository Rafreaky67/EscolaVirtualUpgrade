﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Student : User
    {
        string m_NIF { get; set; }
        Class m_Class { get; set; }
        Card m_Card { get; set; }

        public Student(string nif, string login, string pass, string name,Class class_) : base(login, pass, name)
        {
            m_NIF = nif;
            m_Class = class_;
            m_Card = new Card(0.0);
        }

        public string GetNIF() { return m_NIF; }
        public Class GetClass() { return m_Class; }
        public Card GetCard() { return m_Card; }
    }
}
