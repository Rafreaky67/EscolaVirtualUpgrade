﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Admin : User
    {
        public Admin(string login, string pass, string name) : base (login, pass, name) {   }
    }
}
