﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Class
    {
        string m_Acronym { get; set; }
        int m_MaxStudents { get; set; }
        string m_Year { get; set; }

        public Class(string acronym, int maxstudents, string year)
        { 
            m_Acronym = acronym;
            m_MaxStudents = maxstudents;                        
            m_Year = year;
        }

        public string GetAcronym() { return m_Acronym; }
        public void SetAcronym(string acronym) { m_Acronym = acronym; }
        public int GetMaxStudents() { return m_MaxStudents; }
        public void SetMaxStudents(int maxstudents) { m_MaxStudents = maxstudents; }
        public string GetYear() { return m_Year; }
    }
}
