﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Grade
    {
        Subject m_Subject { get; set; }
        int m_Grade { get; set; }
        Student m_Student { get; set; }

        public Grade(Subject subject, int grade, Student student)
        { 
            m_Subject = subject;
            m_Grade = grade;
            m_Student = student;
        }

        public Subject GetSubject() { return m_Subject; }
        public int GetGrade() { return m_Grade; }
        public Student GetStudent() { return m_Student; }
    }
}
