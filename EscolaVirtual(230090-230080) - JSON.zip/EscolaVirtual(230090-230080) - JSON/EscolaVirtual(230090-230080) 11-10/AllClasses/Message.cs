﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Message
    {
        User m_Receiver;
        User m_Sender;
        string m_Content;
        DateTime m_DateTime;
        bool m_Read;

        public Message(User receiver, User sender, string content, DateTime dateTime)
        { 
            m_Receiver = receiver;
            m_Sender = sender;
            m_Content = content;
            m_DateTime = dateTime;
            m_Read = false;
        }

        public User GetReceiver() { return m_Receiver; }
        public User GetSender() { return m_Sender; }
        public string GetContent() { return m_Content; }
        public DateTime GetDateTime() { return m_DateTime; }
        public bool GetReadStatus() { return m_Read; }
        public void SetReadStatus(bool read) {  m_Read = read; }
    }
}
