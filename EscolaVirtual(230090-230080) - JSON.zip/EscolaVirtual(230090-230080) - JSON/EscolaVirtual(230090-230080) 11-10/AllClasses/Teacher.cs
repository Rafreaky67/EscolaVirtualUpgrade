﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public class Teacher : User
    {
        string m_NIF { get; set; }
        Subject m_Subject { get; set; }
        Class m_Class { get; set; }

        public Teacher(string nif, string login, string pass, string name, Subject subject, Class @class) : base(login, pass, name)
        {
            m_NIF = nif;
            m_Subject = subject;
            m_Class = @class;
        }

        public Subject GetSubject() { return m_Subject; }
        public string GetNIF() { return m_NIF; }
        public Class GetClass() { return m_Class; }
    }
}
