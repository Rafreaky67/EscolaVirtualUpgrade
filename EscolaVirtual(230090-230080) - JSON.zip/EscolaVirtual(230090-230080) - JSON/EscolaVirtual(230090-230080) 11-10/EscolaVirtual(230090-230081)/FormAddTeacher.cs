﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormAddTeacher : Form
    {
        public FormAddTeacher()
        {
            InitializeComponent();
        }

        private void FormAddTeacher_Load(object sender, EventArgs e)
        {

            foreach (Subject itemS in Program.SubjectsList)
            {
                cbbSubjects.Items.Add(itemS.GetName());
            }

            foreach (Year itemY in Program.YearsList)
            {
                cbbYears.Items.Add(itemY.GetYear());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;

            if(!char.IsLetter(c) && c != 8 && c != 46 && c != 32)
                e.Handled = true;
        }

        private void txtNIF_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;

            if (!char.IsDigit(c) && c != 8 && c != 46)
                e.Handled = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && txtNIF.Text != "" && txtLogin.Text != "" && txtPassword.Text != "" && cbbSubjects.SelectedIndex != -1 && cbbYears.SelectedIndex != -1 && cbbClasses.SelectedIndex != -1)
            {
                if (txtNIF.Text.Length != 9)
                {
                    MessageBox.Show("NIF inválido.\n\nNIF tem que ter 9 dígitos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    foreach (Teacher itemT in Program.TeacherList)
                    {
                        foreach (Student itemS in Program.StudentList)
                        {
                            if (txtNIF.Text == itemT.GetNIF() || txtNIF.Text == itemS.GetNIF())
                            {
                                MessageBox.Show("Já existe um utilizador com o mesmo NIF.\n\nNão podem existir NIF iguais.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }

                    foreach (Teacher itemT in Program.TeacherList)
                    {
                        foreach (Student itemS in Program.StudentList)
                        {
                            if (txtLogin.Text == itemT.GetLogin() || txtLogin.Text == itemS.GetLogin())
                            {
                                MessageBox.Show("Já existe um utilizador com o mesmo Login.\n\nNão podem existir logins iguais.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }

                    if (txtLogin.Text.Length != 4)
                    {
                        MessageBox.Show("Login inválido.\n\nO Login não cumpre as normas.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        if (txtLogin.Text.ToUpper()[0] != 'P' || !(txtLogin.Text[1] >= '0' && txtLogin.Text[1] <= '9') || !(txtLogin.Text[2] >= '0' && txtLogin.Text[2] <= '9') || !(txtLogin.Text[3] >= '0' && txtLogin.Text[3] <= '9'))
                        {
                            MessageBox.Show("Login inválido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }

                Teacher newteacher = new Teacher(txtNIF.Text, txtLogin.Text, txtPassword.Text, txtName.Text, new Subject(cbbSubjects.SelectedItem.ToString(), txtLogin.Text), Program.ClassesList.FirstOrDefault(p => p.GetYear() == cbbYears.SelectedItem.ToString() && p.GetAcronym() == cbbClasses.SelectedItem.ToString()));
                Program.TeacherList.Add(newteacher);
                System.IO.File.WriteAllText("TeachersList.json", JsonSettings.Serialize(Program.TeacherList));
                MessageBox.Show("O professor '" + newteacher.GetName() + "' foi adicionado.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Os campos (Nome, NIF, Login, Password e Disciplina) têm que estar preenchidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbbYears_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbbYears.SelectedIndex != -1)
            {
                cbbSubjects.Enabled = true;
                int idx = 0;
                foreach (Year itemY in Program.YearsList)
                {
                    cbbSubjects.Items.Add(itemY.GetSubjects()[idx].GetName());
                    idx++;
                }

                cbbClasses.Enabled = true;
                idx = 0;
                foreach (Year itemY in Program.YearsList)
                {
                    if (itemY.GetClasses() != null)
                    {
                        cbbClasses.Items.Add(itemY.GetClasses()[idx].GetAcronym());
                        idx++;
                    }
                    else
                        break;
                }
            }
            else
            {
                cbbSubjects.Enabled = true;
                cbbClasses.Enabled = true;
            }
        }
    }
}