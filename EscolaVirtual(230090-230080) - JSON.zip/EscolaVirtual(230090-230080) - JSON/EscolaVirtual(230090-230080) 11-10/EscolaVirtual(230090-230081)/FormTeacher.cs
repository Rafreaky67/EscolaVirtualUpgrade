﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormTeacher : Form
    {
        Teacher logedinuser;
        Functions functions = new Functions();

        public FormTeacher(Teacher teacher)
        {
            InitializeComponent();
            logedinuser = teacher;
        }

        private void FormTeacher_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            FormLogIn login = new FormLogIn();
            login.ShowDialog();
        }

        private void FormTeacher_Load(object sender, EventArgs e)
        {
            lblProfileName.Text = logedinuser.GetName();
            panelManagementPanels.Hide();
            panelMenu.Hide();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (panelMenu.Enabled == false)
            {
                panelMenu.Show();
                panelGrades.BackColor = Color.SkyBlue;
                panelMessages.BackColor = Color.SkyBlue;
                panelMenu.Enabled = true;
            }
            else
            {
                panelMenu.Hide();
                panelManagementPanels.Hide();
                panelMenu.Enabled = false;
            }
        }

        private void panelMessages_Click(object sender, EventArgs e)
        {
            panelGrades.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SteelBlue;
            panelManagementPanels.Hide();

            FormMessages messagesform = new FormMessages(logedinuser);
            messagesform.Show();
        }

        private void btnGrades_Click(object sender, EventArgs e)
        {
            panelGrades.BackColor = Color.SteelBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            FormProfile2 formProfile2 = new FormProfile2(logedinuser);
            formProfile2.ShowDialog();
        }

        private void btnCreateGrade_Click(object sender, EventArgs e)
        {
            FormCreateGrade formcreategrade = new FormCreateGrade(logedinuser);
            formcreategrade.ShowDialog();

            functions.UpdateListViewGradesTeacher(lvwGrades, logedinuser);
        }
    }
}
