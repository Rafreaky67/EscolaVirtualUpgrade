﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public class Functions
    {
        public class ListViewItemComparer : IComparer
        {
            private int col;
            public ListViewItemComparer(int column)
            {
                col = column;
            }

            public int Compare(object x, object y)
            {
                return String.Compare(
                    ((ListViewItem)x).SubItems[col].Text,
                    ((ListViewItem)y).SubItems[col].Text
                );
            }
        }

        public void UpdateListViewYears(ListView lvw)
        {
            lvw.Items.Clear();

            foreach (Year itemY in Program.YearsList)
            {
                ListViewItem listviewitem = new ListViewItem();

                listviewitem.Text = itemY.GetYear();

                if (itemY.GetClasses() != null)
                    listviewitem.SubItems.Add(itemY.GetClasses().Count().ToString());
                else
                    listviewitem.SubItems.Add("0");

                lvw.Items.Add(listviewitem);

            }

            lvw.ListViewItemSorter = new ListViewItemComparer(1);
        }

        public void UpdateListViewClasses(ListView lvw)
        {
            lvw.Items.Clear();

            foreach (Year itemY in Program.YearsList)
            {
                foreach (Class itemC in itemY.GetClasses())
                {
                    ListViewItem listviewitem = new ListViewItem();

                    listviewitem.Text = itemC.GetAcronym();
                    listviewitem.SubItems.Add(itemY.GetYear());
                    listviewitem.SubItems.Add(itemC.GetMaxStudents().ToString());

                    lvw.Items.Add(listviewitem);
                }
            }

            lvw.ListViewItemSorter = new ListViewItemComparer(0);
        }

        public void UpdateTreeViewSubjects(TreeView tvw)
        { 
            tvw.Nodes.Clear();

            foreach (Year itemY in Program.YearsList)
            {
                TreeNode yearnode = new TreeNode();
                yearnode.Text = itemY.GetYear();

                tvw.Nodes.Add(yearnode);
                if (itemY.GetSubjects() != null)
                {
                    foreach (Subject itemS in itemY.GetSubjects())
                    {
                        TreeNode subjectnode = new TreeNode();
                        subjectnode.Text = itemS.GetName();

                        yearnode.Nodes.Add(subjectnode);
                    }
                }
            }
        }

        public void UpdateListViewTeachers(ListView lvw)
        {
            lvw.Items.Clear();

            foreach (Teacher itemT in Program.TeacherList)
            { 
                ListViewItem newlvwitem = new ListViewItem();
                newlvwitem.Text = itemT.GetNIF();
                newlvwitem.SubItems.Add(itemT.GetName());
                newlvwitem.SubItems.Add(itemT.GetClass().GetYear() + itemT.GetClass().GetAcronym());
                newlvwitem.SubItems.Add(itemT.GetSubject().GetName());
                

                lvw.Items.Add(newlvwitem);
            }
        }

        public void UpdateListViewStudents(ListView lvw)
        {
            lvw.Items.Clear();

            foreach (Student itemS in Program.StudentList)
            {
                ListViewItem newlvwitem = new ListViewItem();
                newlvwitem.Text = itemS.GetNIF();
                newlvwitem.SubItems.Add(itemS.GetName());
                newlvwitem.SubItems.Add(itemS.GetClass().GetYear());
                newlvwitem.SubItems.Add(itemS.GetClass().GetAcronym());

                lvw.Items.Add(newlvwitem);
            }
        }

        public void UpdateListViewGrades(ListView lvw, User student)
        {
            lvw.Items.Clear();

            foreach (Grade itemG in Program.GradesList)
            {
                if (itemG.GetStudent() == student)
                {
                    ListViewItem newlvwitem = new ListViewItem();
                    newlvwitem.Text = itemG.GetSubject().GetName();
                    newlvwitem.SubItems.Add(itemG.GetGrade().ToString());

                    bool proc = false;
                    foreach (ListViewItem lvwitem in lvw.Items)
                    {
                        if (newlvwitem.Text == lvwitem.Text)
                        {
                            proc = true;
                            break;  
                        }
                    }

                    if (proc)
                        break;
                    else
                        lvw.Items.Add(newlvwitem);
                }
            }
        }

        public void UpdateTreeViewStudents(TreeView tvw, User user)
        {
            tvw.Nodes.Clear();

            foreach (Year itemY in Program.YearsList)
            {
                if (itemY.GetSubjects().Any(p => p.GetTeacher() == user.GetLogin()))
                {
                    TreeNode yearnode = new TreeNode();
                    yearnode.Text = itemY.GetYear();
                    tvw.Nodes.Add(yearnode);
                    foreach (Class itemC in itemY.GetClasses())
                    {
                        TreeNode classnode = new TreeNode();
                        classnode.Text = itemC.GetAcronym();
                        yearnode.Nodes.Add(classnode);
                        foreach (Student itemS in Program.StudentList)
                        {
                            if (itemS.GetClass().GetYear() == itemY.GetYear() && itemS.GetClass().GetAcronym() == itemC.GetAcronym())
                            {
                                TreeNode studentnode = new TreeNode();
                                studentnode.Text = itemS.GetName();
                                classnode.Nodes.Add(studentnode);
                            }
                        }
                    }
                }
            }
        }

        public void UpdateListViewGradesTeacher(ListView lvw, Teacher teacher)
        {
            lvw.Items.Clear();

            foreach (Grade itemG in Program.GradesList)
            {
                if (itemG.GetSubject() == teacher.GetSubject())
                {
                    ListViewItem newlvwitem = new ListViewItem();
                    newlvwitem.Text = itemG.GetStudent().GetName();
                    newlvwitem.SubItems.Add(itemG.GetStudent().GetClass().GetYear() + itemG.GetStudent().GetClass().GetAcronym());
                    newlvwitem.SubItems.Add(itemG.GetSubject().GetName());
                    newlvwitem.SubItems.Add(itemG.GetGrade().ToString() + '%');
                    
                    lvw.Items.Add(newlvwitem);
                }
            }
        }

        public void UpdateMessagesListView(ListView lvw, User user, String user2)
        {
            lvw.Items.Clear();

            foreach (Message message in MessageService.GetMessages())
            {
                if (message.GetSender() == user && message.GetReceiver().GetName() == user2
                    || message.GetSender().GetName() == user2 && message.GetReceiver() == user)
                {
                    ListViewItem lvwitem = new ListViewItem();
                    lvwitem.Text = message.GetSender().GetName() + " => " + message.GetContent();

                    if (message.GetSender().GetLogin()[0] == 'A')
                    { lvwitem.ImageIndex = 0; }
                    else
                    {
                        if (message.GetSender().GetLogin()[0] == 'P')
                        { lvwitem.ImageIndex = 1; }
                        else
                        { lvwitem.ImageIndex = 2; }
                    }

                    lvw.Items.Add(lvwitem);
                }
            }
        }

        public User FindUserByName(String name) 
        {
            foreach (User user in Program.AdminList)
            {
                if (user.GetName() == name)
                    return user;
            }

            foreach (User user in Program.TeacherList)
            {
                if (user.GetName() == name)
                    return user;
            }

            foreach (User user in Program.StudentList)
            {
                if (user.GetName() == name)
                    return user;
            }

            return null;
        }
    }
}