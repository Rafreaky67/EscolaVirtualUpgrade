﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
using System.IO;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormAdmin : Form
    {
        Functions functions = new Functions();
        Admin logedinuser;

        public FormAdmin(Admin user)
        {
            InitializeComponent();
            logedinuser = user;
        }

        private void FormAdmin_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            FormLogIn login = new FormLogIn();
            login.ShowDialog();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            lblProfileName.Text = logedinuser.GetName();
            panelManagementPanels.Hide();
            panelMenu.Hide();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (panelMenu.Enabled == false)
            {
                panelMenu.Show();
                panelYears.BackColor = Color.SkyBlue;
                panelClasses.BackColor = Color.SkyBlue;
                panelSubjects.BackColor = Color.SkyBlue;
                panelTeachers.BackColor = Color.SkyBlue;
                panelStudents.BackColor = Color.SkyBlue;
                panelMessages.BackColor = Color.SkyBlue;
                panelMenu.Enabled = true;
            }
            else
            {
                panelMenu.Hide();
                panelManagementPanels.Hide();
                panelYearsManagement.Hide();
                panelClassesManagement.Hide();
                panelTeachersManagement.Hide();
                panelSubjectsManagement.Hide();
                panelStudentsManagement.Hide();
                panelMenu.Enabled = false;
            }
        }

        private void bntAddYear_Click(object sender, EventArgs e)
        {
            FormAddYear addyearform = new FormAddYear();
            addyearform.ShowDialog();

            functions.UpdateListViewYears(lvwYears);
        }

        private void btnRemoveYear_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lvwYears.Items)
            {
                if (item.Selected == true)
                {
                    lvwYears.Items.Remove(item);
                    JsonSettings.Serialize(Program.YearsList);
                    Program.YearsList.Remove(Program.YearsList.First(p => p.GetYear() == item.Text));
                }
            }

            functions.UpdateListViewYears(lvwYears);
        }

        private void lvwYears_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvwYears.SelectedIndices.Count > 0)
                btnRemoveYear.Enabled = true;
            else
                btnRemoveYear.Enabled = false;
        }

        private void btnYears_Click(object sender, EventArgs e)
        {
            panelYears.BackColor = Color.SteelBlue;
            panelClasses.BackColor = Color.SkyBlue;
            panelTeachers.BackColor = Color.SkyBlue;
            panelSubjects.BackColor = Color.SkyBlue;
            panelStudents.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
            panelYearsManagement.Show();
            panelClassesManagement.Hide();
            panelTeachersManagement.Hide();
            panelSubjectsManagement.Hide();
            panelStudentsManagement.Hide();

            functions.UpdateListViewYears(lvwYears);
        }

        private void btnClasses_Click(object sender, EventArgs e)
        {
            panelYears.BackColor = Color.SkyBlue;
            panelClasses.BackColor = Color.SteelBlue;
            panelTeachers.BackColor = Color.SkyBlue;
            panelSubjects.BackColor = Color.SkyBlue;
            panelStudents.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
            panelClassesManagement.Show();
            panelYearsManagement.Hide();
            panelTeachersManagement.Hide();
            panelSubjectsManagement.Hide();
            panelStudentsManagement.Hide();

            functions.UpdateListViewClasses(lvwClasses);
        }

        private void btnTeacher_Click(object sender, EventArgs e)
        {
            panelYears.BackColor = Color.SkyBlue;
            panelClasses.BackColor = Color.SkyBlue;
            panelTeachers.BackColor = Color.SteelBlue;
            panelSubjects.BackColor = Color.SkyBlue;
            panelStudents.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
            panelTeachersManagement.Show();
            panelYearsManagement.Hide();
            panelClassesManagement.Hide();
            panelSubjectsManagement.Hide();
            panelStudentsManagement.Hide();

            functions.UpdateListViewTeachers(lvwTeachers);
        }

        private void btnSubjects_Click(object sender, EventArgs e)
        {

            panelYears.BackColor = Color.SkyBlue;
            panelClasses.BackColor = Color.SkyBlue;
            panelTeachers.BackColor = Color.SkyBlue;
            panelSubjects.BackColor = Color.SteelBlue;
            panelStudents.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
            panelYearsManagement.Hide();
            panelClassesManagement.Hide();
            panelTeachersManagement.Hide();
            panelSubjectsManagement.Show();
            panelStudentsManagement.Hide();

            functions.UpdateTreeViewSubjects(tvwSubjects);
        }

        private void btnStudents_Click(object sender, EventArgs e)
        {
            panelYears.BackColor = Color.SkyBlue;
            panelClasses.BackColor = Color.SkyBlue;
            panelTeachers.BackColor = Color.SkyBlue;
            panelSubjects.BackColor = Color.SkyBlue;
            panelStudents.BackColor = Color.SteelBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
            panelStudentsManagement.Show();
            panelYearsManagement.Hide();
            panelClassesManagement.Hide();
            panelSubjectsManagement.Hide();
            panelTeachersManagement.Hide();

            functions.UpdateListViewStudents(lvwStudents);
        }

        private void btnMessages_Click(object sender, EventArgs e)
        {
            panelYears.BackColor = Color.SkyBlue;
            panelClasses.BackColor = Color.SkyBlue;
            panelTeachers.BackColor = Color.SkyBlue;
            panelSubjects.BackColor = Color.SkyBlue;
            panelStudents.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SteelBlue;
            panelManagementPanels.Hide();
            panelStudentsManagement.Hide();
            panelYearsManagement.Hide();
            panelClassesManagement.Hide();
            panelSubjectsManagement.Hide();
            panelTeachersManagement.Hide();

            FormMessages messagesform = new FormMessages(logedinuser);
            messagesform.Show();
        }

        private void btnAddClass_Click(object sender, EventArgs e)
        {
            FormAddClass addclassform = new FormAddClass();
            addclassform.ShowDialog();

            functions.UpdateListViewClasses(lvwClasses);
        }

        private void btnRemoveClass_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvwitem in lvwClasses.Items)
            {
                if (lvwitem.Selected)
                {
                    bool proc = false;

                    foreach (Year itemY in Program.YearsList)
                    {
                        foreach (Class itemC in itemY.GetClasses())
                        {
                            proc = itemY.GetYear() == lvwitem.SubItems[1].Text &&
                                    itemC.GetAcronym() == lvwitem.Text;

                            if (proc)
                            {
                                itemY.GetClasses().Remove(itemY.GetClasses().First(p => p.GetAcronym() == lvwitem.Text  && 
                                                                                   itemY.GetYear() == lvwitem.SubItems[1].Text));
                                File.WriteAllText("YearsList.json", JsonSettings.Serialize(Program.YearsList));
                                MessageBox.Show("A turma " + '"' + itemC.GetAcronym() + '"' + " foi removida do " + itemY.GetYear() + " ano.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                break;
                            }
                        }
                    }
                }
            }

            functions.UpdateListViewClasses(lvwClasses);
        }

        private void lvwClasses_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvwClasses.SelectedIndices.Count > 0)
                btnRemoveClass.Enabled = true;
            else
                btnRemoveClass.Enabled = false;
        }

        private void btnAddSubjects_Click(object sender, EventArgs e)
        {
            FormAddSubject addsubjectform = new FormAddSubject();
            addsubjectform.ShowDialog();

            functions.UpdateTreeViewSubjects(tvwSubjects);
        }

        private void btnCreateSubject_Click(object sender, EventArgs e)
        {
            FormCreateSubject createsubjectform = new FormCreateSubject();
            createsubjectform.ShowDialog();
        }

        private void btnRemoveSubject_Click(object sender, EventArgs e)
        {
            foreach (TreeNode parentnode in tvwSubjects.Nodes)
            {
                if (parentnode.IsSelected == true)
                {
                    MessageBox.Show("Não pode apagar anos aqui.\n\nVá á página de gestão de anos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                }
                else
                {
                    foreach (TreeNode node in parentnode.Nodes)
                    {
                        if (node.IsSelected == true)
                        {
                            parentnode.Nodes.Remove(node);
                            foreach (Year itemY in Program.YearsList)
                            {
                                if (itemY.GetYear() == parentnode.Text)
                                {
                                    foreach (Subject itemS in itemY.GetSubjects())
                                    {
                                        if (itemS.GetName() == node.Text)
                                        {
                                            itemY.RemoveSubject(itemS);
                                            System.IO.File.WriteAllText("YearsList.json", JsonSettings.Serialize(Program.YearsList));
                                            MessageBox.Show("A disciplina " + '"' + itemS.GetName() + '"' + " foi removida do " + itemY.GetYear() + " ano.", "Info",MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            functions.UpdateTreeViewSubjects(tvwSubjects);
        }

        private void btnAddTeacher_Click(object sender, EventArgs e)
        {
            FormAddTeacher formAddTeacher = new FormAddTeacher();
            formAddTeacher.ShowDialog();

            functions.UpdateListViewTeachers(lvwTeachers);
        }

        private void btnRemoveTeacher_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvwitem in lvwTeachers.Items)
            {
                if (lvwitem.Selected == true)
                {
                    bool proc = false;

                    foreach (Teacher itemT in Program.TeacherList)
                    {
                        proc = itemT.GetNIF() == lvwitem.Text;

                        if (proc)
                        { 
                            Program.TeacherList.Remove(itemT);
                            System.IO.File.WriteAllText("TeachersList.json", JsonSettings.Serialize(Program.TeacherList));
                            MessageBox.Show("O professor '" + itemT.GetName() + "' foi removido.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                }
            }

            functions.UpdateListViewTeachers(lvwTeachers);
        }

        private void lvwTeachers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvwTeachers.SelectedItems.Count > 0)
                btnRemoveTeacher.Enabled = true;
        }

        private void btnRemoveStudent_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvwitem in lvwStudents.Items)
            {
                if (lvwitem.Selected == true)
                {
                    bool proc = false;

                    foreach (Student itemS in Program.StudentList)
                    {
                        proc = itemS.GetNIF() == lvwitem.Text;

                        if (proc)
                        {
                            Program.StudentList.Remove(itemS);
                            System.IO.File.WriteAllText("StudentsList.json", JsonSettings.Serialize(Program.StudentList));
                            MessageBox.Show("O aluno '" + itemS.GetName() + "' foi removido.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                }
            }

            functions.UpdateListViewStudents(lvwStudents);
        }

        private void lvwStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lvwStudents.SelectedItems.Count > 0)
                btnRemoveStudent.Enabled = true;
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            FormAddStudent formAddStudent = new FormAddStudent();
            formAddStudent.ShowDialog();

            functions.UpdateListViewStudents(lvwStudents);
        }

        private void lvwStudents_DoubleClick(object sender, EventArgs e)
        {
            FormProfile formProfile = new FormProfile(Program.StudentList.First(p => p.GetNIF() == lvwStudents.FocusedItem.Text));
            formProfile.ShowDialog();
        }

        private void lvwTeachers_DoubleClick(object sender, EventArgs e)
        {
            FormProfile formProfile = new FormProfile(Program.TeacherList.First(p => p.GetNIF() == lvwTeachers.FocusedItem.Text));
            formProfile.ShowDialog();
        }
    }
}