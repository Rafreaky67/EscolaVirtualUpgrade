﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace EscolaVirtual_230090_230081_
{
    public static class JsonSettings
    {
        public static readonly JsonSerializerSettings Options = new JsonSerializerSettings
        {
            ContractResolver = new DefaultContractResolver
            {
                DefaultMembersSearchFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance
            }
        };

        public static string Serialize<T>(T obj)
        {
            return JsonConvert.SerializeObject(obj, Options);
        }
    }
}
