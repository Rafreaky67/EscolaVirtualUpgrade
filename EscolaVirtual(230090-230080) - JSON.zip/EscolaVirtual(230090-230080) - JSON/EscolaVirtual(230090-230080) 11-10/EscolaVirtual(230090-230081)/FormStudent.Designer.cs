﻿namespace EscolaVirtual_230090_230081_
{
    partial class FormStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProfileName = new System.Windows.Forms.Label();
            this.lblMenu = new System.Windows.Forms.Label();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelSchoolCard = new System.Windows.Forms.Panel();
            this.lblSchoolCard = new System.Windows.Forms.Label();
            this.btnSchoolCard = new System.Windows.Forms.Button();
            this.panelMessages = new System.Windows.Forms.Panel();
            this.lblMessages = new System.Windows.Forms.Label();
            this.btnMessages = new System.Windows.Forms.Button();
            this.panelGrades = new System.Windows.Forms.Panel();
            this.lblGrades = new System.Windows.Forms.Label();
            this.btnGrades = new System.Windows.Forms.Button();
            this.panelManagementPanels = new System.Windows.Forms.Panel();
            this.panelGradesManagement = new System.Windows.Forms.Panel();
            this.lvwGrades = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelSchoolCardManagement = new System.Windows.Forms.Panel();
            this.btnDeposit = new System.Windows.Forms.Button();
            this.txtDeposit = new System.Windows.Forms.TextBox();
            this.lblDeposit = new System.Windows.Forms.Label();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.lbBalance = new System.Windows.Forms.Label();
            this.lblYearAndClass = new System.Windows.Forms.Label();
            this.lblStudentName = new System.Windows.Forms.Label();
            this.lblSchoolName = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelMenu.SuspendLayout();
            this.panelSchoolCard.SuspendLayout();
            this.panelMessages.SuspendLayout();
            this.panelGrades.SuspendLayout();
            this.panelManagementPanels.SuspendLayout();
            this.panelGradesManagement.SuspendLayout();
            this.panelSchoolCardManagement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblProfileName
            // 
            this.lblProfileName.AutoSize = true;
            this.lblProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfileName.Location = new System.Drawing.Point(49, 13);
            this.lblProfileName.Name = "lblProfileName";
            this.lblProfileName.Size = new System.Drawing.Size(57, 20);
            this.lblProfileName.TabIndex = 14;
            this.lblProfileName.Text = "label1";
            this.lblProfileName.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // lblMenu
            // 
            this.lblMenu.AutoSize = true;
            this.lblMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMenu.Location = new System.Drawing.Point(48, 70);
            this.lblMenu.Name = "lblMenu";
            this.lblMenu.Size = new System.Drawing.Size(53, 20);
            this.lblMenu.TabIndex = 22;
            this.lblMenu.Text = "Menu";
            this.lblMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelMenu.Controls.Add(this.panelSchoolCard);
            this.panelMenu.Controls.Add(this.panelMessages);
            this.panelMenu.Controls.Add(this.panelGrades);
            this.panelMenu.Enabled = false;
            this.panelMenu.ForeColor = System.Drawing.Color.Transparent;
            this.panelMenu.Location = new System.Drawing.Point(24, 107);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(198, 152);
            this.panelMenu.TabIndex = 23;
            // 
            // panelSchoolCard
            // 
            this.panelSchoolCard.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelSchoolCard.Controls.Add(this.lblSchoolCard);
            this.panelSchoolCard.Controls.Add(this.btnSchoolCard);
            this.panelSchoolCard.Location = new System.Drawing.Point(2, 52);
            this.panelSchoolCard.Name = "panelSchoolCard";
            this.panelSchoolCard.Size = new System.Drawing.Size(193, 47);
            this.panelSchoolCard.TabIndex = 18;
            this.panelSchoolCard.Click += new System.EventHandler(this.panelSchoolCard_Click);
            // 
            // lblSchoolCard
            // 
            this.lblSchoolCard.AutoSize = true;
            this.lblSchoolCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSchoolCard.ForeColor = System.Drawing.Color.Black;
            this.lblSchoolCard.Location = new System.Drawing.Point(49, 12);
            this.lblSchoolCard.Name = "lblSchoolCard";
            this.lblSchoolCard.Size = new System.Drawing.Size(63, 20);
            this.lblSchoolCard.TabIndex = 13;
            this.lblSchoolCard.Text = "Cartão";
            this.lblSchoolCard.Click += new System.EventHandler(this.panelSchoolCard_Click);
            // 
            // btnSchoolCard
            // 
            this.btnSchoolCard.BackColor = System.Drawing.Color.Transparent;
            this.btnSchoolCard.FlatAppearance.BorderSize = 0;
            this.btnSchoolCard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSchoolCard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSchoolCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSchoolCard.ForeColor = System.Drawing.Color.Transparent;
            this.btnSchoolCard.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Cartão;
            this.btnSchoolCard.Location = new System.Drawing.Point(3, 3);
            this.btnSchoolCard.Name = "btnSchoolCard";
            this.btnSchoolCard.Size = new System.Drawing.Size(40, 40);
            this.btnSchoolCard.TabIndex = 11;
            this.btnSchoolCard.UseVisualStyleBackColor = false;
            this.btnSchoolCard.Click += new System.EventHandler(this.panelSchoolCard_Click);
            // 
            // panelMessages
            // 
            this.panelMessages.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelMessages.Controls.Add(this.lblMessages);
            this.panelMessages.Controls.Add(this.btnMessages);
            this.panelMessages.Location = new System.Drawing.Point(2, 101);
            this.panelMessages.Name = "panelMessages";
            this.panelMessages.Size = new System.Drawing.Size(193, 47);
            this.panelMessages.TabIndex = 17;
            this.panelMessages.Click += new System.EventHandler(this.panelMessages_Click);
            // 
            // lblMessages
            // 
            this.lblMessages.AutoSize = true;
            this.lblMessages.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessages.ForeColor = System.Drawing.Color.Black;
            this.lblMessages.Location = new System.Drawing.Point(49, 12);
            this.lblMessages.Name = "lblMessages";
            this.lblMessages.Size = new System.Drawing.Size(101, 20);
            this.lblMessages.TabIndex = 13;
            this.lblMessages.Text = "Mensagens";
            this.lblMessages.Click += new System.EventHandler(this.panelMessages_Click);
            // 
            // btnMessages
            // 
            this.btnMessages.BackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatAppearance.BorderSize = 0;
            this.btnMessages.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMessages.ForeColor = System.Drawing.Color.Transparent;
            this.btnMessages.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Mensagens;
            this.btnMessages.Location = new System.Drawing.Point(3, 3);
            this.btnMessages.Name = "btnMessages";
            this.btnMessages.Size = new System.Drawing.Size(40, 40);
            this.btnMessages.TabIndex = 11;
            this.btnMessages.UseVisualStyleBackColor = false;
            this.btnMessages.Click += new System.EventHandler(this.panelMessages_Click);
            // 
            // panelGrades
            // 
            this.panelGrades.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelGrades.Controls.Add(this.lblGrades);
            this.panelGrades.Controls.Add(this.btnGrades);
            this.panelGrades.Location = new System.Drawing.Point(2, 3);
            this.panelGrades.Name = "panelGrades";
            this.panelGrades.Size = new System.Drawing.Size(193, 47);
            this.panelGrades.TabIndex = 16;
            this.panelGrades.Click += new System.EventHandler(this.panelGrades_Click);
            // 
            // lblGrades
            // 
            this.lblGrades.AutoSize = true;
            this.lblGrades.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrades.ForeColor = System.Drawing.Color.Black;
            this.lblGrades.Location = new System.Drawing.Point(49, 12);
            this.lblGrades.Name = "lblGrades";
            this.lblGrades.Size = new System.Drawing.Size(56, 20);
            this.lblGrades.TabIndex = 13;
            this.lblGrades.Text = "Notas";
            this.lblGrades.Click += new System.EventHandler(this.panelGrades_Click);
            // 
            // btnGrades
            // 
            this.btnGrades.BackColor = System.Drawing.Color.Transparent;
            this.btnGrades.FlatAppearance.BorderSize = 0;
            this.btnGrades.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGrades.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGrades.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGrades.ForeColor = System.Drawing.Color.Transparent;
            this.btnGrades.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Notas;
            this.btnGrades.Location = new System.Drawing.Point(3, 3);
            this.btnGrades.Name = "btnGrades";
            this.btnGrades.Size = new System.Drawing.Size(40, 40);
            this.btnGrades.TabIndex = 11;
            this.btnGrades.UseVisualStyleBackColor = false;
            this.btnGrades.Click += new System.EventHandler(this.panelGrades_Click);
            // 
            // panelManagementPanels
            // 
            this.panelManagementPanels.Controls.Add(this.panelGradesManagement);
            this.panelManagementPanels.Controls.Add(this.panelSchoolCardManagement);
            this.panelManagementPanels.Location = new System.Drawing.Point(261, 70);
            this.panelManagementPanels.Name = "panelManagementPanels";
            this.panelManagementPanels.Size = new System.Drawing.Size(491, 331);
            this.panelManagementPanels.TabIndex = 24;
            // 
            // panelGradesManagement
            // 
            this.panelGradesManagement.BackColor = System.Drawing.Color.Silver;
            this.panelGradesManagement.Controls.Add(this.lvwGrades);
            this.panelGradesManagement.Location = new System.Drawing.Point(0, 0);
            this.panelGradesManagement.Name = "panelGradesManagement";
            this.panelGradesManagement.Size = new System.Drawing.Size(491, 331);
            this.panelGradesManagement.TabIndex = 11;
            // 
            // lvwGrades
            // 
            this.lvwGrades.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvwGrades.FullRowSelect = true;
            this.lvwGrades.HideSelection = false;
            this.lvwGrades.Location = new System.Drawing.Point(13, 12);
            this.lvwGrades.Name = "lvwGrades";
            this.lvwGrades.Size = new System.Drawing.Size(464, 305);
            this.lvwGrades.TabIndex = 0;
            this.lvwGrades.UseCompatibleStateImageBehavior = false;
            this.lvwGrades.View = System.Windows.Forms.View.Details;
            this.lvwGrades.DoubleClick += new System.EventHandler(this.lvwGrades_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Disciplina";
            this.columnHeader1.Width = 106;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nota(Média)";
            this.columnHeader2.Width = 354;
            // 
            // panelSchoolCardManagement
            // 
            this.panelSchoolCardManagement.BackColor = System.Drawing.Color.Silver;
            this.panelSchoolCardManagement.Controls.Add(this.btnDeposit);
            this.panelSchoolCardManagement.Controls.Add(this.txtDeposit);
            this.panelSchoolCardManagement.Controls.Add(this.lblDeposit);
            this.panelSchoolCardManagement.Controls.Add(this.txtBalance);
            this.panelSchoolCardManagement.Controls.Add(this.lbBalance);
            this.panelSchoolCardManagement.Controls.Add(this.lblYearAndClass);
            this.panelSchoolCardManagement.Controls.Add(this.lblStudentName);
            this.panelSchoolCardManagement.Controls.Add(this.lblSchoolName);
            this.panelSchoolCardManagement.Controls.Add(this.pictureBox4);
            this.panelSchoolCardManagement.Controls.Add(this.pictureBox3);
            this.panelSchoolCardManagement.Controls.Add(this.pictureBox2);
            this.panelSchoolCardManagement.Location = new System.Drawing.Point(0, 0);
            this.panelSchoolCardManagement.Name = "panelSchoolCardManagement";
            this.panelSchoolCardManagement.Size = new System.Drawing.Size(491, 331);
            this.panelSchoolCardManagement.TabIndex = 0;
            // 
            // btnDeposit
            // 
            this.btnDeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeposit.Location = new System.Drawing.Point(304, 191);
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(155, 31);
            this.btnDeposit.TabIndex = 10;
            this.btnDeposit.Text = "Depositar";
            this.btnDeposit.UseVisualStyleBackColor = true;
            this.btnDeposit.Click += new System.EventHandler(this.btnDeposit_Click);
            // 
            // txtDeposit
            // 
            this.txtDeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeposit.Location = new System.Drawing.Point(289, 146);
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.Size = new System.Drawing.Size(188, 38);
            this.txtDeposit.TabIndex = 9;
            this.txtDeposit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // lblDeposit
            // 
            this.lblDeposit.AutoSize = true;
            this.lblDeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeposit.Location = new System.Drawing.Point(285, 119);
            this.lblDeposit.Name = "lblDeposit";
            this.lblDeposit.Size = new System.Drawing.Size(174, 24);
            this.lblDeposit.TabIndex = 8;
            this.lblDeposit.Text = "Valor a depositar:";
            // 
            // txtBalance
            // 
            this.txtBalance.Enabled = false;
            this.txtBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalance.Location = new System.Drawing.Point(290, 59);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(188, 38);
            this.txtBalance.TabIndex = 7;
            // 
            // lbBalance
            // 
            this.lbBalance.AutoSize = true;
            this.lbBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBalance.Location = new System.Drawing.Point(286, 32);
            this.lbBalance.Name = "lbBalance";
            this.lbBalance.Size = new System.Drawing.Size(69, 24);
            this.lbBalance.TabIndex = 6;
            this.lbBalance.Text = "Saldo:";
            // 
            // lblYearAndClass
            // 
            this.lblYearAndClass.AutoSize = true;
            this.lblYearAndClass.BackColor = System.Drawing.Color.White;
            this.lblYearAndClass.Location = new System.Drawing.Point(83, 138);
            this.lblYearAndClass.Name = "lblYearAndClass";
            this.lblYearAndClass.Size = new System.Drawing.Size(35, 13);
            this.lblYearAndClass.TabIndex = 5;
            this.lblYearAndClass.Text = "label1";
            // 
            // lblStudentName
            // 
            this.lblStudentName.AutoSize = true;
            this.lblStudentName.BackColor = System.Drawing.Color.White;
            this.lblStudentName.Location = new System.Drawing.Point(83, 119);
            this.lblStudentName.Name = "lblStudentName";
            this.lblStudentName.Size = new System.Drawing.Size(35, 13);
            this.lblStudentName.TabIndex = 4;
            this.lblStudentName.Text = "label1";
            // 
            // lblSchoolName
            // 
            this.lblSchoolName.AutoSize = true;
            this.lblSchoolName.BackColor = System.Drawing.Color.White;
            this.lblSchoolName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSchoolName.Location = new System.Drawing.Point(73, 52);
            this.lblSchoolName.Name = "lblSchoolName";
            this.lblSchoolName.Size = new System.Drawing.Size(115, 20);
            this.lblSchoolName.TabIndex = 3;
            this.lblSchoolName.Text = "EscolaVirtual";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.White;
            this.pictureBox4.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Logo;
            this.pictureBox4.Location = new System.Drawing.Point(31, 32);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(46, 40);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Aluno;
            this.pictureBox3.Location = new System.Drawing.Point(37, 115);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 40);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Cartão21;
            this.pictureBox2.Location = new System.Drawing.Point(0, -29);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(279, 251);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.ForeColor = System.Drawing.Color.Transparent;
            this.btnMenu.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Menu;
            this.btnMenu.Location = new System.Drawing.Point(2, 61);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(40, 40);
            this.btnMenu.TabIndex = 21;
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.Color.Transparent;
            this.btnMinimize.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Minimize;
            this.btnMinimize.Location = new System.Drawing.Point(712, 3);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(40, 40);
            this.btnMinimize.TabIndex = 16;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogOut.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.LogOut1;
            this.btnLogOut.Location = new System.Drawing.Point(758, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(40, 40);
            this.btnLogOut.TabIndex = 15;
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.ForeColor = System.Drawing.Color.Transparent;
            this.btnProfile.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Aluno;
            this.btnProfile.Location = new System.Drawing.Point(3, 3);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(40, 40);
            this.btnProfile.TabIndex = 13;
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Ondas_Azuis;
            this.pictureBox1.Location = new System.Drawing.Point(-9, 219);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(821, 250);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // FormStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelManagementPanels);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.lblMenu);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnMinimize);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.lblProfileName);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormStudent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormStudent";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormStudent_FormClosed);
            this.Load += new System.EventHandler(this.FormStudent_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelSchoolCard.ResumeLayout(false);
            this.panelSchoolCard.PerformLayout();
            this.panelMessages.ResumeLayout(false);
            this.panelMessages.PerformLayout();
            this.panelGrades.ResumeLayout(false);
            this.panelGrades.PerformLayout();
            this.panelManagementPanels.ResumeLayout(false);
            this.panelGradesManagement.ResumeLayout(false);
            this.panelSchoolCardManagement.ResumeLayout(false);
            this.panelSchoolCardManagement.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblProfileName;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label lblMenu;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelMessages;
        private System.Windows.Forms.Label lblMessages;
        private System.Windows.Forms.Button btnMessages;
        private System.Windows.Forms.Panel panelGrades;
        private System.Windows.Forms.Label lblGrades;
        private System.Windows.Forms.Button btnGrades;
        private System.Windows.Forms.Panel panelManagementPanels;
        private System.Windows.Forms.Panel panelSchoolCard;
        private System.Windows.Forms.Label lblSchoolCard;
        private System.Windows.Forms.Button btnSchoolCard;
        private System.Windows.Forms.Panel panelSchoolCardManagement;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lblStudentName;
        private System.Windows.Forms.Label lblSchoolName;
        private System.Windows.Forms.Button btnDeposit;
        private System.Windows.Forms.TextBox txtDeposit;
        private System.Windows.Forms.Label lblDeposit;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Label lbBalance;
        private System.Windows.Forms.Label lblYearAndClass;
        private System.Windows.Forms.Panel panelGradesManagement;
        private System.Windows.Forms.ListView lvwGrades;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}