﻿namespace EscolaVirtual_230090_230081_
{
    partial class FormCreateGrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnCreateGrade = new System.Windows.Forms.Button();
            this.tvwStudents = new System.Windows.Forms.TreeView();
            this.lblNota = new System.Windows.Forms.Label();
            this.txtGrade = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(311, 306);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(131, 28);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancelar";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnCreateGrade
            // 
            this.btnCreateGrade.Location = new System.Drawing.Point(27, 306);
            this.btnCreateGrade.Margin = new System.Windows.Forms.Padding(4);
            this.btnCreateGrade.Name = "btnCreateGrade";
            this.btnCreateGrade.Size = new System.Drawing.Size(131, 28);
            this.btnCreateGrade.TabIndex = 7;
            this.btnCreateGrade.Text = "Dar nota";
            this.btnCreateGrade.UseVisualStyleBackColor = true;
            this.btnCreateGrade.Click += new System.EventHandler(this.btnCreateGrade_Click);
            // 
            // tvwStudents
            // 
            this.tvwStudents.Location = new System.Drawing.Point(17, 16);
            this.tvwStudents.Margin = new System.Windows.Forms.Padding(4);
            this.tvwStudents.Name = "tvwStudents";
            this.tvwStudents.Size = new System.Drawing.Size(437, 248);
            this.tvwStudents.TabIndex = 9;
            // 
            // lblNota
            // 
            this.lblNota.AutoSize = true;
            this.lblNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNota.Location = new System.Drawing.Point(16, 268);
            this.lblNota.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNota.Name = "lblNota";
            this.lblNota.Size = new System.Drawing.Size(54, 20);
            this.lblNota.TabIndex = 10;
            this.lblNota.Text = "Nota:";
            // 
            // txtGrade
            // 
            this.txtGrade.Location = new System.Drawing.Point(83, 268);
            this.txtGrade.Margin = new System.Windows.Forms.Padding(4);
            this.txtGrade.MaxLength = 3;
            this.txtGrade.Name = "txtGrade";
            this.txtGrade.Size = new System.Drawing.Size(136, 22);
            this.txtGrade.TabIndex = 11;
            this.txtGrade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGrade_KeyPress);
            // 
            // FormCreateGrade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(472, 348);
            this.Controls.Add(this.txtGrade);
            this.Controls.Add(this.lblNota);
            this.Controls.Add(this.tvwStudents);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnCreateGrade);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormCreateGrade";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormCreateGrade";
            this.Load += new System.EventHandler(this.FormCreateGrade_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnCreateGrade;
        private System.Windows.Forms.TreeView tvwStudents;
        private System.Windows.Forms.Label lblNota;
        private System.Windows.Forms.TextBox txtGrade;
    }
}