﻿namespace EscolaVirtual_230090_230081_
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProfileName = new System.Windows.Forms.Label();
            this.panelYears = new System.Windows.Forms.Panel();
            this.lblYears = new System.Windows.Forms.Label();
            this.btnYears = new System.Windows.Forms.Button();
            this.panelClasses = new System.Windows.Forms.Panel();
            this.lblClasses = new System.Windows.Forms.Label();
            this.btnClasses = new System.Windows.Forms.Button();
            this.panelTeachers = new System.Windows.Forms.Panel();
            this.lblTeachers = new System.Windows.Forms.Label();
            this.btnTeacher = new System.Windows.Forms.Button();
            this.panelStudents = new System.Windows.Forms.Panel();
            this.lblStudents = new System.Windows.Forms.Label();
            this.btnStudents = new System.Windows.Forms.Button();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelSubjects = new System.Windows.Forms.Panel();
            this.lblSubjects = new System.Windows.Forms.Label();
            this.btnSubjects = new System.Windows.Forms.Button();
            this.panelMessages = new System.Windows.Forms.Panel();
            this.lblMessages = new System.Windows.Forms.Label();
            this.btnMessages = new System.Windows.Forms.Button();
            this.lblMenu = new System.Windows.Forms.Label();
            this.panelYearsManagement = new System.Windows.Forms.Panel();
            this.btnRemoveYear = new System.Windows.Forms.Button();
            this.bntAddYear = new System.Windows.Forms.Button();
            this.lvwYears = new System.Windows.Forms.ListView();
            this.chYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chClassesQuantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelClassesManagement = new System.Windows.Forms.Panel();
            this.btnRemoveClass = new System.Windows.Forms.Button();
            this.btnAddClass = new System.Windows.Forms.Button();
            this.lvwClasses = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelTeachersManagement = new System.Windows.Forms.Panel();
            this.btnRemoveTeacher = new System.Windows.Forms.Button();
            this.btnAddTeacher = new System.Windows.Forms.Button();
            this.lvwTeachers = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelStudentsManagement = new System.Windows.Forms.Panel();
            this.lvwStudents = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnRemoveStudent = new System.Windows.Forms.Button();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.panelManagementPanels = new System.Windows.Forms.Panel();
            this.panelSubjectsManagement = new System.Windows.Forms.Panel();
            this.btnCreateSubject = new System.Windows.Forms.Button();
            this.tvwSubjects = new System.Windows.Forms.TreeView();
            this.btnRemoveSubject = new System.Windows.Forms.Button();
            this.btnAddSubjects = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelYears.SuspendLayout();
            this.panelClasses.SuspendLayout();
            this.panelTeachers.SuspendLayout();
            this.panelStudents.SuspendLayout();
            this.panelMenu.SuspendLayout();
            this.panelSubjects.SuspendLayout();
            this.panelMessages.SuspendLayout();
            this.panelYearsManagement.SuspendLayout();
            this.panelClassesManagement.SuspendLayout();
            this.panelTeachersManagement.SuspendLayout();
            this.panelStudentsManagement.SuspendLayout();
            this.panelManagementPanels.SuspendLayout();
            this.panelSubjectsManagement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblProfileName
            // 
            this.lblProfileName.AutoSize = true;
            this.lblProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfileName.Location = new System.Drawing.Point(64, 15);
            this.lblProfileName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProfileName.Name = "lblProfileName";
            this.lblProfileName.Size = new System.Drawing.Size(70, 25);
            this.lblProfileName.TabIndex = 10;
            this.lblProfileName.Text = "label1";
            // 
            // panelYears
            // 
            this.panelYears.BackColor = System.Drawing.Color.SkyBlue;
            this.panelYears.Controls.Add(this.lblYears);
            this.panelYears.Controls.Add(this.btnYears);
            this.panelYears.Location = new System.Drawing.Point(3, 4);
            this.panelYears.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelYears.Name = "panelYears";
            this.panelYears.Size = new System.Drawing.Size(257, 58);
            this.panelYears.TabIndex = 12;
            this.panelYears.Click += new System.EventHandler(this.btnYears_Click);
            // 
            // lblYears
            // 
            this.lblYears.AutoSize = true;
            this.lblYears.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYears.ForeColor = System.Drawing.Color.Black;
            this.lblYears.Location = new System.Drawing.Point(65, 15);
            this.lblYears.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYears.Name = "lblYears";
            this.lblYears.Size = new System.Drawing.Size(62, 25);
            this.lblYears.TabIndex = 13;
            this.lblYears.Text = "Anos";
            this.lblYears.Click += new System.EventHandler(this.btnYears_Click);
            // 
            // btnYears
            // 
            this.btnYears.BackColor = System.Drawing.Color.Transparent;
            this.btnYears.FlatAppearance.BorderSize = 0;
            this.btnYears.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnYears.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnYears.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYears.ForeColor = System.Drawing.Color.Transparent;
            this.btnYears.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Ano_escolar;
            this.btnYears.Location = new System.Drawing.Point(4, 4);
            this.btnYears.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnYears.Name = "btnYears";
            this.btnYears.Size = new System.Drawing.Size(53, 49);
            this.btnYears.TabIndex = 11;
            this.btnYears.UseVisualStyleBackColor = false;
            this.btnYears.Click += new System.EventHandler(this.btnYears_Click);
            // 
            // panelClasses
            // 
            this.panelClasses.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelClasses.Controls.Add(this.lblClasses);
            this.panelClasses.Controls.Add(this.btnClasses);
            this.panelClasses.Location = new System.Drawing.Point(3, 69);
            this.panelClasses.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelClasses.Name = "panelClasses";
            this.panelClasses.Size = new System.Drawing.Size(257, 58);
            this.panelClasses.TabIndex = 14;
            this.panelClasses.Click += new System.EventHandler(this.btnClasses_Click);
            // 
            // lblClasses
            // 
            this.lblClasses.AutoSize = true;
            this.lblClasses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClasses.ForeColor = System.Drawing.Color.Black;
            this.lblClasses.Location = new System.Drawing.Point(65, 15);
            this.lblClasses.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblClasses.Name = "lblClasses";
            this.lblClasses.Size = new System.Drawing.Size(85, 25);
            this.lblClasses.TabIndex = 13;
            this.lblClasses.Text = "Turmas";
            this.lblClasses.Click += new System.EventHandler(this.btnClasses_Click);
            // 
            // btnClasses
            // 
            this.btnClasses.BackColor = System.Drawing.Color.Transparent;
            this.btnClasses.FlatAppearance.BorderSize = 0;
            this.btnClasses.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClasses.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnClasses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClasses.ForeColor = System.Drawing.Color.Transparent;
            this.btnClasses.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Turma;
            this.btnClasses.Location = new System.Drawing.Point(4, 4);
            this.btnClasses.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClasses.Name = "btnClasses";
            this.btnClasses.Size = new System.Drawing.Size(53, 49);
            this.btnClasses.TabIndex = 11;
            this.btnClasses.UseVisualStyleBackColor = false;
            this.btnClasses.Click += new System.EventHandler(this.btnClasses_Click);
            // 
            // panelTeachers
            // 
            this.panelTeachers.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelTeachers.Controls.Add(this.lblTeachers);
            this.panelTeachers.Controls.Add(this.btnTeacher);
            this.panelTeachers.Location = new System.Drawing.Point(3, 197);
            this.panelTeachers.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelTeachers.Name = "panelTeachers";
            this.panelTeachers.Size = new System.Drawing.Size(257, 58);
            this.panelTeachers.TabIndex = 15;
            this.panelTeachers.Click += new System.EventHandler(this.btnTeacher_Click);
            // 
            // lblTeachers
            // 
            this.lblTeachers.AutoSize = true;
            this.lblTeachers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeachers.ForeColor = System.Drawing.Color.Black;
            this.lblTeachers.Location = new System.Drawing.Point(65, 15);
            this.lblTeachers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTeachers.Name = "lblTeachers";
            this.lblTeachers.Size = new System.Drawing.Size(127, 25);
            this.lblTeachers.TabIndex = 13;
            this.lblTeachers.Text = "Professores";
            this.lblTeachers.Click += new System.EventHandler(this.btnTeacher_Click);
            // 
            // btnTeacher
            // 
            this.btnTeacher.BackColor = System.Drawing.Color.Transparent;
            this.btnTeacher.FlatAppearance.BorderSize = 0;
            this.btnTeacher.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTeacher.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTeacher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTeacher.ForeColor = System.Drawing.Color.Transparent;
            this.btnTeacher.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Professor;
            this.btnTeacher.Location = new System.Drawing.Point(4, 4);
            this.btnTeacher.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTeacher.Name = "btnTeacher";
            this.btnTeacher.Size = new System.Drawing.Size(53, 49);
            this.btnTeacher.TabIndex = 11;
            this.btnTeacher.UseVisualStyleBackColor = false;
            this.btnTeacher.Click += new System.EventHandler(this.btnTeacher_Click);
            // 
            // panelStudents
            // 
            this.panelStudents.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelStudents.Controls.Add(this.lblStudents);
            this.panelStudents.Controls.Add(this.btnStudents);
            this.panelStudents.Location = new System.Drawing.Point(4, 262);
            this.panelStudents.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelStudents.Name = "panelStudents";
            this.panelStudents.Size = new System.Drawing.Size(257, 58);
            this.panelStudents.TabIndex = 16;
            this.panelStudents.Click += new System.EventHandler(this.btnStudents_Click);
            // 
            // lblStudents
            // 
            this.lblStudents.AutoSize = true;
            this.lblStudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudents.ForeColor = System.Drawing.Color.Black;
            this.lblStudents.Location = new System.Drawing.Point(65, 15);
            this.lblStudents.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStudents.Name = "lblStudents";
            this.lblStudents.Size = new System.Drawing.Size(79, 25);
            this.lblStudents.TabIndex = 13;
            this.lblStudents.Text = "Alunos";
            this.lblStudents.Click += new System.EventHandler(this.btnStudents_Click);
            // 
            // btnStudents
            // 
            this.btnStudents.BackColor = System.Drawing.Color.Transparent;
            this.btnStudents.FlatAppearance.BorderSize = 0;
            this.btnStudents.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnStudents.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudents.ForeColor = System.Drawing.Color.Transparent;
            this.btnStudents.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Aluno;
            this.btnStudents.Location = new System.Drawing.Point(4, 4);
            this.btnStudents.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnStudents.Name = "btnStudents";
            this.btnStudents.Size = new System.Drawing.Size(53, 49);
            this.btnStudents.TabIndex = 11;
            this.btnStudents.UseVisualStyleBackColor = false;
            this.btnStudents.Click += new System.EventHandler(this.btnStudents_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelMenu.Controls.Add(this.panelSubjects);
            this.panelMenu.Controls.Add(this.panelMessages);
            this.panelMenu.Controls.Add(this.panelYears);
            this.panelMenu.Controls.Add(this.panelStudents);
            this.panelMenu.Controls.Add(this.panelClasses);
            this.panelMenu.Controls.Add(this.panelTeachers);
            this.panelMenu.Enabled = false;
            this.panelMenu.ForeColor = System.Drawing.Color.Transparent;
            this.panelMenu.Location = new System.Drawing.Point(32, 132);
            this.panelMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(264, 389);
            this.panelMenu.TabIndex = 17;
            // 
            // panelSubjects
            // 
            this.panelSubjects.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelSubjects.Controls.Add(this.lblSubjects);
            this.panelSubjects.Controls.Add(this.btnSubjects);
            this.panelSubjects.Location = new System.Drawing.Point(3, 134);
            this.panelSubjects.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelSubjects.Name = "panelSubjects";
            this.panelSubjects.Size = new System.Drawing.Size(257, 58);
            this.panelSubjects.TabIndex = 18;
            this.panelSubjects.Click += new System.EventHandler(this.btnSubjects_Click);
            // 
            // lblSubjects
            // 
            this.lblSubjects.AutoSize = true;
            this.lblSubjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubjects.ForeColor = System.Drawing.Color.Black;
            this.lblSubjects.Location = new System.Drawing.Point(65, 15);
            this.lblSubjects.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSubjects.Name = "lblSubjects";
            this.lblSubjects.Size = new System.Drawing.Size(116, 25);
            this.lblSubjects.TabIndex = 13;
            this.lblSubjects.Text = "Disciplinas";
            this.lblSubjects.Click += new System.EventHandler(this.btnSubjects_Click);
            // 
            // btnSubjects
            // 
            this.btnSubjects.BackColor = System.Drawing.Color.Transparent;
            this.btnSubjects.FlatAppearance.BorderSize = 0;
            this.btnSubjects.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSubjects.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSubjects.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubjects.ForeColor = System.Drawing.Color.Transparent;
            this.btnSubjects.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Disciplinas;
            this.btnSubjects.Location = new System.Drawing.Point(4, 4);
            this.btnSubjects.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSubjects.Name = "btnSubjects";
            this.btnSubjects.Size = new System.Drawing.Size(53, 49);
            this.btnSubjects.TabIndex = 11;
            this.btnSubjects.UseVisualStyleBackColor = false;
            this.btnSubjects.Click += new System.EventHandler(this.btnSubjects_Click);
            // 
            // panelMessages
            // 
            this.panelMessages.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelMessages.Controls.Add(this.lblMessages);
            this.panelMessages.Controls.Add(this.btnMessages);
            this.panelMessages.Location = new System.Drawing.Point(4, 327);
            this.panelMessages.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelMessages.Name = "panelMessages";
            this.panelMessages.Size = new System.Drawing.Size(257, 58);
            this.panelMessages.TabIndex = 17;
            this.panelMessages.Click += new System.EventHandler(this.btnMessages_Click);
            // 
            // lblMessages
            // 
            this.lblMessages.AutoSize = true;
            this.lblMessages.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessages.ForeColor = System.Drawing.Color.Black;
            this.lblMessages.Location = new System.Drawing.Point(65, 15);
            this.lblMessages.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMessages.Name = "lblMessages";
            this.lblMessages.Size = new System.Drawing.Size(124, 25);
            this.lblMessages.TabIndex = 13;
            this.lblMessages.Text = "Mensagens";
            this.lblMessages.Click += new System.EventHandler(this.btnMessages_Click);
            // 
            // btnMessages
            // 
            this.btnMessages.BackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatAppearance.BorderSize = 0;
            this.btnMessages.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMessages.ForeColor = System.Drawing.Color.Transparent;
            this.btnMessages.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Mensagens;
            this.btnMessages.Location = new System.Drawing.Point(4, 4);
            this.btnMessages.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMessages.Name = "btnMessages";
            this.btnMessages.Size = new System.Drawing.Size(53, 49);
            this.btnMessages.TabIndex = 11;
            this.btnMessages.UseVisualStyleBackColor = false;
            this.btnMessages.Click += new System.EventHandler(this.btnMessages_Click);
            // 
            // lblMenu
            // 
            this.lblMenu.AutoSize = true;
            this.lblMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMenu.Location = new System.Drawing.Point(64, 86);
            this.lblMenu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMenu.Name = "lblMenu";
            this.lblMenu.Size = new System.Drawing.Size(66, 25);
            this.lblMenu.TabIndex = 18;
            this.lblMenu.Text = "Menu";
            this.lblMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // panelYearsManagement
            // 
            this.panelYearsManagement.BackColor = System.Drawing.Color.Silver;
            this.panelYearsManagement.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelYearsManagement.Controls.Add(this.btnRemoveYear);
            this.panelYearsManagement.Controls.Add(this.bntAddYear);
            this.panelYearsManagement.Controls.Add(this.lvwYears);
            this.panelYearsManagement.Location = new System.Drawing.Point(0, 0);
            this.panelYearsManagement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelYearsManagement.Name = "panelYearsManagement";
            this.panelYearsManagement.Size = new System.Drawing.Size(653, 406);
            this.panelYearsManagement.TabIndex = 19;
            // 
            // btnRemoveYear
            // 
            this.btnRemoveYear.Enabled = false;
            this.btnRemoveYear.Location = new System.Drawing.Point(459, 356);
            this.btnRemoveYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveYear.Name = "btnRemoveYear";
            this.btnRemoveYear.Size = new System.Drawing.Size(155, 36);
            this.btnRemoveYear.TabIndex = 2;
            this.btnRemoveYear.Text = "Remover ano";
            this.btnRemoveYear.UseVisualStyleBackColor = true;
            this.btnRemoveYear.Click += new System.EventHandler(this.btnRemoveYear_Click);
            // 
            // bntAddYear
            // 
            this.bntAddYear.Location = new System.Drawing.Point(36, 356);
            this.bntAddYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bntAddYear.Name = "bntAddYear";
            this.bntAddYear.Size = new System.Drawing.Size(155, 36);
            this.bntAddYear.TabIndex = 1;
            this.bntAddYear.Text = "Adicionar ano";
            this.bntAddYear.UseVisualStyleBackColor = true;
            this.bntAddYear.Click += new System.EventHandler(this.bntAddYear_Click);
            // 
            // lvwYears
            // 
            this.lvwYears.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chYear,
            this.chClassesQuantity});
            this.lvwYears.FullRowSelect = true;
            this.lvwYears.HideSelection = false;
            this.lvwYears.Location = new System.Drawing.Point(19, 21);
            this.lvwYears.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lvwYears.MultiSelect = false;
            this.lvwYears.Name = "lvwYears";
            this.lvwYears.Size = new System.Drawing.Size(611, 326);
            this.lvwYears.TabIndex = 0;
            this.lvwYears.UseCompatibleStateImageBehavior = false;
            this.lvwYears.View = System.Windows.Forms.View.Details;
            this.lvwYears.SelectedIndexChanged += new System.EventHandler(this.lvwYears_SelectedIndexChanged);
            // 
            // chYear
            // 
            this.chYear.Text = "Ano";
            // 
            // chClassesQuantity
            // 
            this.chClassesQuantity.Text = "Quantidade de turmas";
            this.chClassesQuantity.Width = 395;
            // 
            // panelClassesManagement
            // 
            this.panelClassesManagement.BackColor = System.Drawing.Color.Silver;
            this.panelClassesManagement.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelClassesManagement.Controls.Add(this.btnRemoveClass);
            this.panelClassesManagement.Controls.Add(this.btnAddClass);
            this.panelClassesManagement.Controls.Add(this.lvwClasses);
            this.panelClassesManagement.Location = new System.Drawing.Point(0, 0);
            this.panelClassesManagement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelClassesManagement.Name = "panelClassesManagement";
            this.panelClassesManagement.Size = new System.Drawing.Size(653, 406);
            this.panelClassesManagement.TabIndex = 20;
            // 
            // btnRemoveClass
            // 
            this.btnRemoveClass.Enabled = false;
            this.btnRemoveClass.Location = new System.Drawing.Point(459, 356);
            this.btnRemoveClass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveClass.Name = "btnRemoveClass";
            this.btnRemoveClass.Size = new System.Drawing.Size(155, 36);
            this.btnRemoveClass.TabIndex = 2;
            this.btnRemoveClass.Text = "Remover turma";
            this.btnRemoveClass.UseVisualStyleBackColor = true;
            this.btnRemoveClass.Click += new System.EventHandler(this.btnRemoveClass_Click);
            // 
            // btnAddClass
            // 
            this.btnAddClass.Location = new System.Drawing.Point(36, 356);
            this.btnAddClass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddClass.Name = "btnAddClass";
            this.btnAddClass.Size = new System.Drawing.Size(155, 36);
            this.btnAddClass.TabIndex = 1;
            this.btnAddClass.Text = "Adicionar turma";
            this.btnAddClass.UseVisualStyleBackColor = true;
            this.btnAddClass.Click += new System.EventHandler(this.btnAddClass_Click);
            // 
            // lvwClasses
            // 
            this.lvwClasses.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader1,
            this.columnHeader8});
            this.lvwClasses.FullRowSelect = true;
            this.lvwClasses.HideSelection = false;
            this.lvwClasses.Location = new System.Drawing.Point(19, 21);
            this.lvwClasses.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lvwClasses.MultiSelect = false;
            this.lvwClasses.Name = "lvwClasses";
            this.lvwClasses.Size = new System.Drawing.Size(611, 326);
            this.lvwClasses.TabIndex = 0;
            this.lvwClasses.UseCompatibleStateImageBehavior = false;
            this.lvwClasses.View = System.Windows.Forms.View.Details;
            this.lvwClasses.SelectedIndexChanged += new System.EventHandler(this.lvwClasses_SelectedIndexChanged);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Turma";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Ano";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Quantidade máxima de alunos";
            this.columnHeader8.Width = 216;
            // 
            // panelTeachersManagement
            // 
            this.panelTeachersManagement.BackColor = System.Drawing.Color.Silver;
            this.panelTeachersManagement.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelTeachersManagement.Controls.Add(this.btnRemoveTeacher);
            this.panelTeachersManagement.Controls.Add(this.btnAddTeacher);
            this.panelTeachersManagement.Controls.Add(this.lvwTeachers);
            this.panelTeachersManagement.Location = new System.Drawing.Point(0, 0);
            this.panelTeachersManagement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelTeachersManagement.Name = "panelTeachersManagement";
            this.panelTeachersManagement.Size = new System.Drawing.Size(653, 406);
            this.panelTeachersManagement.TabIndex = 20;
            // 
            // btnRemoveTeacher
            // 
            this.btnRemoveTeacher.Enabled = false;
            this.btnRemoveTeacher.Location = new System.Drawing.Point(459, 356);
            this.btnRemoveTeacher.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveTeacher.Name = "btnRemoveTeacher";
            this.btnRemoveTeacher.Size = new System.Drawing.Size(155, 36);
            this.btnRemoveTeacher.TabIndex = 2;
            this.btnRemoveTeacher.Text = "Remover Professor";
            this.btnRemoveTeacher.UseVisualStyleBackColor = true;
            this.btnRemoveTeacher.Click += new System.EventHandler(this.btnRemoveTeacher_Click);
            // 
            // btnAddTeacher
            // 
            this.btnAddTeacher.Location = new System.Drawing.Point(36, 356);
            this.btnAddTeacher.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddTeacher.Name = "btnAddTeacher";
            this.btnAddTeacher.Size = new System.Drawing.Size(155, 36);
            this.btnAddTeacher.TabIndex = 1;
            this.btnAddTeacher.Text = "Adicionar Professor";
            this.btnAddTeacher.UseVisualStyleBackColor = true;
            this.btnAddTeacher.Click += new System.EventHandler(this.btnAddTeacher_Click);
            // 
            // lvwTeachers
            // 
            this.lvwTeachers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader7,
            this.columnHeader3});
            this.lvwTeachers.FullRowSelect = true;
            this.lvwTeachers.HideSelection = false;
            this.lvwTeachers.Location = new System.Drawing.Point(19, 21);
            this.lvwTeachers.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lvwTeachers.MultiSelect = false;
            this.lvwTeachers.Name = "lvwTeachers";
            this.lvwTeachers.Size = new System.Drawing.Size(611, 326);
            this.lvwTeachers.TabIndex = 0;
            this.lvwTeachers.UseCompatibleStateImageBehavior = false;
            this.lvwTeachers.View = System.Windows.Forms.View.Details;
            this.lvwTeachers.SelectedIndexChanged += new System.EventHandler(this.lvwTeachers_SelectedIndexChanged);
            this.lvwTeachers.DoubleClick += new System.EventHandler(this.lvwTeachers_DoubleClick);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "NIF";
            this.columnHeader4.Width = 100;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Nome";
            this.columnHeader5.Width = 209;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Disciplina";
            this.columnHeader3.Width = 169;
            // 
            // panelStudentsManagement
            // 
            this.panelStudentsManagement.BackColor = System.Drawing.Color.Silver;
            this.panelStudentsManagement.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelStudentsManagement.Controls.Add(this.lvwStudents);
            this.panelStudentsManagement.Controls.Add(this.btnRemoveStudent);
            this.panelStudentsManagement.Controls.Add(this.btnAddStudent);
            this.panelStudentsManagement.Location = new System.Drawing.Point(0, 0);
            this.panelStudentsManagement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelStudentsManagement.Name = "panelStudentsManagement";
            this.panelStudentsManagement.Size = new System.Drawing.Size(653, 406);
            this.panelStudentsManagement.TabIndex = 20;
            // 
            // lvwStudents
            // 
            this.lvwStudents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader6});
            this.lvwStudents.FullRowSelect = true;
            this.lvwStudents.HideSelection = false;
            this.lvwStudents.Location = new System.Drawing.Point(24, 26);
            this.lvwStudents.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lvwStudents.MultiSelect = false;
            this.lvwStudents.Name = "lvwStudents";
            this.lvwStudents.Size = new System.Drawing.Size(611, 326);
            this.lvwStudents.TabIndex = 3;
            this.lvwStudents.UseCompatibleStateImageBehavior = false;
            this.lvwStudents.View = System.Windows.Forms.View.Details;
            this.lvwStudents.SelectedIndexChanged += new System.EventHandler(this.lvwStudents_SelectedIndexChanged);
            this.lvwStudents.DoubleClick += new System.EventHandler(this.lvwStudents_DoubleClick);
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "NIF";
            this.columnHeader9.Width = 100;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Nome";
            this.columnHeader10.Width = 209;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Ano";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Turma";
            // 
            // btnRemoveStudent
            // 
            this.btnRemoveStudent.Enabled = false;
            this.btnRemoveStudent.Location = new System.Drawing.Point(459, 356);
            this.btnRemoveStudent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveStudent.Name = "btnRemoveStudent";
            this.btnRemoveStudent.Size = new System.Drawing.Size(155, 36);
            this.btnRemoveStudent.TabIndex = 2;
            this.btnRemoveStudent.Text = "Remover aluno";
            this.btnRemoveStudent.UseVisualStyleBackColor = true;
            this.btnRemoveStudent.Click += new System.EventHandler(this.btnRemoveStudent_Click);
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.Location = new System.Drawing.Point(36, 356);
            this.btnAddStudent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(155, 36);
            this.btnAddStudent.TabIndex = 1;
            this.btnAddStudent.Text = "Adicionar aluno";
            this.btnAddStudent.UseVisualStyleBackColor = true;
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // 
            // panelManagementPanels
            // 
            this.panelManagementPanels.Controls.Add(this.panelTeachersManagement);
            this.panelManagementPanels.Controls.Add(this.panelStudentsManagement);
            this.panelManagementPanels.Controls.Add(this.panelSubjectsManagement);
            this.panelManagementPanels.Controls.Add(this.panelYearsManagement);
            this.panelManagementPanels.Controls.Add(this.panelClassesManagement);
            this.panelManagementPanels.Location = new System.Drawing.Point(348, 86);
            this.panelManagementPanels.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelManagementPanels.Name = "panelManagementPanels";
            this.panelManagementPanels.Size = new System.Drawing.Size(655, 407);
            this.panelManagementPanels.TabIndex = 21;
            // 
            // panelSubjectsManagement
            // 
            this.panelSubjectsManagement.BackColor = System.Drawing.Color.Silver;
            this.panelSubjectsManagement.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelSubjectsManagement.Controls.Add(this.btnCreateSubject);
            this.panelSubjectsManagement.Controls.Add(this.tvwSubjects);
            this.panelSubjectsManagement.Controls.Add(this.btnRemoveSubject);
            this.panelSubjectsManagement.Controls.Add(this.btnAddSubjects);
            this.panelSubjectsManagement.Location = new System.Drawing.Point(0, 0);
            this.panelSubjectsManagement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelSubjectsManagement.Name = "panelSubjectsManagement";
            this.panelSubjectsManagement.Size = new System.Drawing.Size(653, 406);
            this.panelSubjectsManagement.TabIndex = 21;
            // 
            // btnCreateSubject
            // 
            this.btnCreateSubject.Location = new System.Drawing.Point(36, 356);
            this.btnCreateSubject.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCreateSubject.Name = "btnCreateSubject";
            this.btnCreateSubject.Size = new System.Drawing.Size(155, 36);
            this.btnCreateSubject.TabIndex = 4;
            this.btnCreateSubject.Text = "Criar disciplina";
            this.btnCreateSubject.UseVisualStyleBackColor = true;
            this.btnCreateSubject.Click += new System.EventHandler(this.btnCreateSubject_Click);
            // 
            // tvwSubjects
            // 
            this.tvwSubjects.Location = new System.Drawing.Point(19, 21);
            this.tvwSubjects.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tvwSubjects.Name = "tvwSubjects";
            this.tvwSubjects.Size = new System.Drawing.Size(611, 326);
            this.tvwSubjects.TabIndex = 3;
            // 
            // btnRemoveSubject
            // 
            this.btnRemoveSubject.Location = new System.Drawing.Point(459, 356);
            this.btnRemoveSubject.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveSubject.Name = "btnRemoveSubject";
            this.btnRemoveSubject.Size = new System.Drawing.Size(155, 36);
            this.btnRemoveSubject.TabIndex = 2;
            this.btnRemoveSubject.Text = "Remover disciplina";
            this.btnRemoveSubject.UseVisualStyleBackColor = true;
            this.btnRemoveSubject.Click += new System.EventHandler(this.btnRemoveSubject_Click);
            // 
            // btnAddSubjects
            // 
            this.btnAddSubjects.Location = new System.Drawing.Point(248, 356);
            this.btnAddSubjects.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddSubjects.Name = "btnAddSubjects";
            this.btnAddSubjects.Size = new System.Drawing.Size(153, 36);
            this.btnAddSubjects.TabIndex = 1;
            this.btnAddSubjects.Text = "Adicionar disciplina";
            this.btnAddSubjects.UseVisualStyleBackColor = true;
            this.btnAddSubjects.Click += new System.EventHandler(this.btnAddSubjects_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.ForeColor = System.Drawing.Color.Transparent;
            this.btnMenu.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Menu;
            this.btnMenu.Location = new System.Drawing.Point(3, 75);
            this.btnMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(53, 49);
            this.btnMenu.TabIndex = 14;
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.ForeColor = System.Drawing.Color.Transparent;
            this.btnProfile.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.User_Perfil_;
            this.btnProfile.Location = new System.Drawing.Point(3, 2);
            this.btnProfile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(53, 49);
            this.btnProfile.TabIndex = 9;
            this.btnProfile.UseVisualStyleBackColor = false;
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.Color.Transparent;
            this.btnMinimize.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Minimize;
            this.btnMinimize.Location = new System.Drawing.Point(949, 2);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(53, 49);
            this.btnMinimize.TabIndex = 8;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogOut.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.LogOut1;
            this.btnLogOut.Location = new System.Drawing.Point(1011, 2);
            this.btnLogOut.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(53, 49);
            this.btnLogOut.TabIndex = 7;
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Ondas_Azuis;
            this.pictureBox1.Location = new System.Drawing.Point(-12, 270);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1095, 308);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // columnHeader7
            // 
            this.columnHeader7.DisplayIndex = 3;
            this.columnHeader7.Text = "Ano/Turma";
            this.columnHeader7.Width = 93;
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.panelManagementPanels);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.lblMenu);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.lblProfileName);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnMinimize);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormAdmin";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormAdmin_FormClosed);
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            this.panelYears.ResumeLayout(false);
            this.panelYears.PerformLayout();
            this.panelClasses.ResumeLayout(false);
            this.panelClasses.PerformLayout();
            this.panelTeachers.ResumeLayout(false);
            this.panelTeachers.PerformLayout();
            this.panelStudents.ResumeLayout(false);
            this.panelStudents.PerformLayout();
            this.panelMenu.ResumeLayout(false);
            this.panelSubjects.ResumeLayout(false);
            this.panelSubjects.PerformLayout();
            this.panelMessages.ResumeLayout(false);
            this.panelMessages.PerformLayout();
            this.panelYearsManagement.ResumeLayout(false);
            this.panelClassesManagement.ResumeLayout(false);
            this.panelTeachersManagement.ResumeLayout(false);
            this.panelStudentsManagement.ResumeLayout(false);
            this.panelManagementPanels.ResumeLayout(false);
            this.panelSubjectsManagement.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Label lblProfileName;
        private System.Windows.Forms.Button btnYears;
        private System.Windows.Forms.Panel panelYears;
        private System.Windows.Forms.Label lblYears;
        private System.Windows.Forms.Panel panelClasses;
        private System.Windows.Forms.Label lblClasses;
        private System.Windows.Forms.Button btnClasses;
        private System.Windows.Forms.Panel panelTeachers;
        private System.Windows.Forms.Label lblTeachers;
        private System.Windows.Forms.Button btnTeacher;
        private System.Windows.Forms.Panel panelStudents;
        private System.Windows.Forms.Label lblStudents;
        private System.Windows.Forms.Button btnStudents;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Label lblMenu;
        private System.Windows.Forms.Panel panelYearsManagement;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView lvwYears;
        private System.Windows.Forms.ColumnHeader chYear;
        private System.Windows.Forms.ColumnHeader chClassesQuantity;
        private System.Windows.Forms.Button btnRemoveYear;
        private System.Windows.Forms.Button bntAddYear;
        private System.Windows.Forms.Panel panelClassesManagement;
        private System.Windows.Forms.Button btnRemoveClass;
        private System.Windows.Forms.Button btnAddClass;
        private System.Windows.Forms.ListView lvwClasses;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Panel panelTeachersManagement;
        private System.Windows.Forms.Button btnRemoveTeacher;
        private System.Windows.Forms.Button btnAddTeacher;
        private System.Windows.Forms.ListView lvwTeachers;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Panel panelStudentsManagement;
        private System.Windows.Forms.Button btnRemoveStudent;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.Panel panelManagementPanels;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Panel panelMessages;
        private System.Windows.Forms.Label lblMessages;
        private System.Windows.Forms.Button btnMessages;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Panel panelSubjects;
        private System.Windows.Forms.Label lblSubjects;
        private System.Windows.Forms.Button btnSubjects;
        private System.Windows.Forms.Panel panelSubjectsManagement;
        private System.Windows.Forms.Button btnRemoveSubject;
        private System.Windows.Forms.Button btnAddSubjects;
        private System.Windows.Forms.TreeView tvwSubjects;
        private System.Windows.Forms.Button btnCreateSubject;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ListView lvwStudents;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
    }
}