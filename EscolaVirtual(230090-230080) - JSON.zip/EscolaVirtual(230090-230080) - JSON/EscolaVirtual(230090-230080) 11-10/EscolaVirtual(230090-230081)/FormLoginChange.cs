﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormLoginChange : Form
    {
        User logedinuser;
        public FormLoginChange(User user)
        {
            InitializeComponent();
            logedinuser = user;
        }

        private void btnSendRequest_Click(object sender, EventArgs e)
        {
            foreach (Teacher itemT in Program.TeacherList)
            {
                foreach (Student itemS in Program.StudentList)
                {
                    if (txtNewLogin.Text == itemT.GetLogin() || txtNewLogin.Text == itemS.GetLogin())
                    {
                        MessageBox.Show("Já existe um utilizador com o mesmo Login.\n\nPeça outro Login.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            Message message = new Message(Program.AdminList[0], logedinuser, $"Quero mudar o meu login para '{txtNewLogin.Text}'.",DateTime.Now);
            MessageService.SendMessage(message);

            MessageBox.Show("Pedido enviado.");
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
