﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormCreateGrade : Form
    {
        Functions functions = new Functions();
        Teacher logedinuser;

        public FormCreateGrade(Teacher user)
        {
            InitializeComponent();
            logedinuser = user;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormCreateGrade_Load(object sender, EventArgs e)
        {
            functions.UpdateTreeViewStudents(tvwStudents, logedinuser);
        }

        private void btnCreateGrade_Click(object sender, EventArgs e)
        {
            bool proc = false;

            foreach (TreeNode yearnode in tvwStudents.Nodes)
            {
                foreach (TreeNode classnode in yearnode.Nodes)
                {
                    foreach (TreeNode studentnode in classnode.Nodes)
                    {
                        if (studentnode.IsSelected == true)
                        {
                            Grade grade = new Grade(logedinuser.GetSubject(), Convert.ToInt16(txtGrade.Text), Program.StudentList.First(p => p.GetName() == studentnode.Text));
                            Program.GradesList.Add(grade);
                            System.IO.File.WriteAllText("GradesList.json", JsonSettings.Serialize(Program.GradesList));
                            proc = true;
                            break;
                        }
                    }
                    if (proc) { break; }
                }
                if (proc) { break; }
            }

            if (txtGrade.Text == "")
                MessageBox.Show("Tem que escrever a nota que pretende dar.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            { 
                if(Convert.ToInt16(txtGrade.Text) < 0 || Convert.ToInt16(txtGrade.Text) > 100)
                    MessageBox.Show("A nota é entre 0 e 100.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (proc)
            {
                MessageBox.Show("Nota lançada.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Tem que selecionar o aluno a que quer dar a nota.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtGrade_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;

            if (!char.IsDigit(c) && c != 8)
                e.Handled = true;
        }
    }
}
