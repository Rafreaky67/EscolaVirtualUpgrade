﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormMessages : Form
    {
        User logedinuser;
        Functions functions = new Functions();

        public FormMessages(User user)
        {
            InitializeComponent();
            logedinuser = user;
        }
        private void btnCloseForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormMessages_Load(object sender, EventArgs e)
        {
            lblProfileName.Text = logedinuser.GetName();
            panelMessages.Hide();

            if (logedinuser.GetLogin() == "Master")
            {
                foreach (User user in Program.StudentList)
                {
                    ListViewItem listViewItem = new ListViewItem();

                    listViewItem.Text = user.GetName();
                    listViewItem.ImageIndex = 0;

                    lvwContacts.Items.Add(listViewItem);
                }
                foreach (User user2 in Program.TeacherList)
                {
                    ListViewItem listViewItem2 = new ListViewItem();


                    listViewItem2.Text = user2.GetName();
                    listViewItem2.ImageIndex = 1;

                    lvwContacts.Items.Add(listViewItem2);
                }

                lvwContacts.ListViewItemSorter = new ListViewImageComparer();
            }
            else
            {
                if (logedinuser.GetLogin()[0] == 'P')
                {
                    foreach (Student userS in Program.StudentList)
                    {
                        ListViewItem listViewItem = new ListViewItem();

                        listViewItem.Text = userS.GetName();
                        listViewItem.ImageIndex = 0;

                        lvwContacts.Items.Add(listViewItem);

                    }
                    foreach (Admin userA in Program.AdminList)
                    {
                        ListViewItem listViewItem = new ListViewItem();


                        listViewItem.Text = userA.GetName();
                        listViewItem.ImageIndex = 2;

                        lvwContacts.Items.Add(listViewItem);
                    }
                    lvwContacts.ListViewItemSorter = new ListViewImageComparer();
                }
                else
                {
                    foreach (Teacher userT in Program.TeacherList)
                    {
                        ListViewItem listViewItem2 = new ListViewItem();


                        listViewItem2.Text = userT.GetName();
                        listViewItem2.ImageIndex = 1;

                        lvwContacts.Items.Add(listViewItem2);
                    }
                    foreach (Student userS in Program.StudentList)
                    {
                        if (logedinuser.GetName() != userS.GetName())
                        {
                            ListViewItem listViewItem2 = new ListViewItem();


                            listViewItem2.Text = userS.GetName();
                            listViewItem2.ImageIndex = 0;

                            lvwContacts.Items.Add(listViewItem2);
                        }
                    }
                    foreach (Admin userA in Program.AdminList)
                    {
                        ListViewItem listViewItem = new ListViewItem();


                        listViewItem.Text = userA.GetName();
                        listViewItem.ImageIndex = 2;

                        lvwContacts.Items.Add(listViewItem);
                    }
                    lvwContacts.ListViewItemSorter = new ListViewImageComparer();

                }
            }

            foreach (ListViewItem lvwitem in lvwContacts.Items)
            {
                int notis = MessageService.GetNonRead(logedinuser, functions.FindUserByName(lvwitem.Text));
                if (notis > 0)
                    lvwitem.BackColor = Color.Red;
                else
                    lvwitem.BackColor = Color.LightGray;
            }
        }

        public class ListViewImageComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                ListViewItem itemX = (ListViewItem)x;
                ListViewItem itemY = (ListViewItem)y;

                return itemX.ImageIndex.CompareTo(itemY.ImageIndex);
            }
        }

        private void lvwContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            panelMessages.Show();
            foreach (ListViewItem item in lvwContacts.Items)
            {
                if (item.Selected == true)
                {
                    imageSelectedContact.Image = imageList1.Images[item.ImageIndex];
                    lblSelectedContact.Text = item.Text;
                    item.BackColor = Color.LightGray;
                }
            }

            functions.UpdateMessagesListView(lvwMessages, logedinuser, lblSelectedContact.Text);
            MessageService.CheckRead(logedinuser, functions.FindUserByName(lblSelectedContact.Text));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (txtMessage.Text == "")
                pctSendMessage.Enabled = false;
            else
                pctSendMessage.Enabled = true;
        }

        private void pctSendMessage_Click(object sender, EventArgs e)
        {
            User msgreceiver = null;

            foreach (Teacher itemT in Program.TeacherList)
            {
                if (msgreceiver != null)
                    break;
                else
                { 
                    if(itemT.GetName() == lblSelectedContact.Text)
                        msgreceiver = itemT;
                }
            }

            foreach (Student itemS in Program.StudentList)
            {
                if (msgreceiver != null)
                    break;
                else
                {
                    if (itemS.GetName() == lblSelectedContact.Text)
                        msgreceiver = itemS;
                }
            }

            foreach (User itemU in Program.AdminList)
            {
                if (msgreceiver != null)
                    break;
                else
                {
                    if (itemU.GetName() == lblSelectedContact.Text)
                        msgreceiver = itemU;
                }
            }

            Message msg = new Message(msgreceiver, logedinuser, txtMessage.Text, DateTime.Now);

            MessageService.SendMessage(msg);
            txtMessage.Clear();

            functions.UpdateMessagesListView(lvwMessages, logedinuser, lblSelectedContact.Text);
        }
    }
}