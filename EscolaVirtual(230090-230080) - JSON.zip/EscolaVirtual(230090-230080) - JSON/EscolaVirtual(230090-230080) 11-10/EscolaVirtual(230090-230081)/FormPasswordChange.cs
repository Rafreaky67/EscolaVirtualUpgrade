﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormPasswordChange : Form
    {
        User logedinuser;
        public FormPasswordChange(User user)
        {
            InitializeComponent();
            logedinuser = user;
        }

        private void btnSendRequest_Click(object sender, EventArgs e)
        {
            Message message = new Message(Program.AdminList[0], logedinuser, $"Quero mudar a minha password para '{txtNewPassword.Text}'.", DateTime.Now);
            MessageService.SendMessage(message);

            MessageBox.Show("Pedido enviado.");
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
