﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormProfile2 : Form
    {
        User logedinuser;

        public FormProfile2(User user)
        {
            InitializeComponent();
            logedinuser = user;
        }

        private void FormProfile2_Load(object sender, EventArgs e)
        {
            if (Program.TeacherList.Contains(logedinuser))
            {
                pictureBox2.Image = imageList1.Images[1];
                Teacher teacher = Program.TeacherList.First(p => p.GetLogin() == logedinuser.GetLogin());
                txtNIF.Text = teacher.GetNIF();
            }
            else
            {
                pictureBox2.Image = imageList1.Images[0];
                Student student = Program.StudentList.First(p => p.GetLogin() == logedinuser.GetLogin());
                txtNIF.Text = student.GetNIF();
            }

            lblProfileName.Text = logedinuser.GetName();
            txtName.Text = logedinuser.GetName();
            txtLogin.Text = logedinuser.GetLogin();
            txtPassword.Text = logedinuser.GetPassword();
        }

        private void btnCloseForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRequestLogInChange_Click(object sender, EventArgs e)
        {
            FormLoginChange formLoginChange = new FormLoginChange(logedinuser);
            formLoginChange.ShowDialog();
        }

        private void btnRequestPasswordChange_Click(object sender, EventArgs e)
        {
            FormPasswordChange formPasswordChange = new FormPasswordChange(logedinuser);
            formPasswordChange.ShowDialog();
        }
    }
}
