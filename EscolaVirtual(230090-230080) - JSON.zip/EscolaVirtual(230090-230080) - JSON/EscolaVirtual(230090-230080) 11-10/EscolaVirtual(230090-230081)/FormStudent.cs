﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormStudent : Form
    {
        Student logedinuser;
        Functions functions = new Functions();

        public FormStudent(Student student)
        {
            InitializeComponent();
            logedinuser = student;
        }

        private void FormStudent_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            FormLogIn login = new FormLogIn();
            login.ShowDialog();
        }

        private void FormStudent_Load(object sender, EventArgs e)
        {
            lblProfileName.Text = logedinuser.GetName();
            panelManagementPanels.Hide();
            panelMenu.Hide();

            txtBalance.Text = logedinuser.GetCard().GetBalance().ToString() + '€';
            lblStudentName.Text = logedinuser.GetName();
            lblYearAndClass.Text = logedinuser.GetClass().GetYear() + logedinuser.GetClass().GetAcronym();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (panelMenu.Enabled == false)
            {
                panelMenu.Show();
                panelGrades.BackColor = Color.SkyBlue;
                panelMessages.BackColor = Color.SkyBlue;
                panelMenu.Enabled = true;
            }
            else
            {
                panelMenu.Hide();
                panelManagementPanels.Hide();
                panelMenu.Enabled = false;
            }
        }

        private void panelMessages_Click(object sender, EventArgs e)
        {
            panelGrades.BackColor = Color.SkyBlue;
            panelSchoolCard.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SteelBlue;
            panelManagementPanels.Hide();

            FormMessages messagesform = new FormMessages(logedinuser);
            messagesform.Show();
        }

        private void panelGrades_Click(object sender, EventArgs e)
        {
            panelGrades.BackColor = Color.SteelBlue;
            panelSchoolCard.BackColor = Color.SkyBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
            panelGradesManagement.Show();
            panelSchoolCardManagement.Hide();

            functions.UpdateListViewGrades(lvwGrades, logedinuser);
        }

        private void panelSchoolCard_Click(object sender, EventArgs e)
        {
            panelGrades.BackColor = Color.SkyBlue;
            panelSchoolCard.BackColor = Color.SteelBlue;
            panelMessages.BackColor = Color.SkyBlue;
            panelManagementPanels.Show();
            panelGradesManagement.Hide();
            panelSchoolCardManagement.Show();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;

            if (!char.IsDigit(c) && c != 8 && c != ',')
                e.Handled = true;
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            if (logedinuser.GetCard().Deposit(Convert.ToDouble(txtDeposit.Text)))
            {
                MessageBox.Show("Depósito feito com sucesso.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtBalance.Text = logedinuser.GetCard().GetBalance().ToString() + '€';
                txtDeposit.Text = "";
            }
            else
                MessageBox.Show("Valor a depositar inválido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

            System.IO.File.WriteAllText("StudentList.json", JsonSettings.Serialize(Program.StudentList));
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            FormProfile2 formProfile2 = new FormProfile2(logedinuser);
            formProfile2.ShowDialog();
        }

        private void lvwGrades_DoubleClick(object sender, EventArgs e)
        {
            List<int> grades = new List<int>();
            foreach (Grade itemG in Program.GradesList)
            {
                if (itemG.GetStudent() == logedinuser && itemG.GetSubject().GetName() == lvwGrades.FocusedItem.Text)
                    grades.Add(itemG.GetGrade());
            }

            string gradesText = string.Join("\n- ", grades);

            MessageBox.Show($"- {gradesText}",$"Notas de {lvwGrades.FocusedItem.Text}");
        }
    }
}
