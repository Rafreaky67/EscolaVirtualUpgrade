﻿namespace EscolaVirtual_230090_230081_
{
    partial class FormMessages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMessages));
            this.lblProfileName = new System.Windows.Forms.Label();
            this.lvwContacts = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblContacts = new System.Windows.Forms.Label();
            this.panelMessages = new System.Windows.Forms.Panel();
            this.lvwMessages = new System.Windows.Forms.ListView();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.pctSendMessage = new System.Windows.Forms.PictureBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.imageSelectedContact = new System.Windows.Forms.PictureBox();
            this.lblSelectedContact = new System.Windows.Forms.Label();
            this.btnCloseForm = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnProfile = new System.Windows.Forms.Button();
            this.panelMessages.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctSendMessage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageSelectedContact)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblProfileName
            // 
            this.lblProfileName.AutoSize = true;
            this.lblProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfileName.Location = new System.Drawing.Point(48, 12);
            this.lblProfileName.Name = "lblProfileName";
            this.lblProfileName.Size = new System.Drawing.Size(57, 20);
            this.lblProfileName.TabIndex = 14;
            this.lblProfileName.Text = "label1";
            // 
            // lvwContacts
            // 
            this.lvwContacts.BackColor = System.Drawing.Color.LightGray;
            this.lvwContacts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.lvwContacts.FullRowSelect = true;
            this.lvwContacts.HideSelection = false;
            this.lvwContacts.Location = new System.Drawing.Point(2, 81);
            this.lvwContacts.MultiSelect = false;
            this.lvwContacts.Name = "lvwContacts";
            this.lvwContacts.Size = new System.Drawing.Size(216, 254);
            this.lvwContacts.SmallImageList = this.imageList1;
            this.lvwContacts.TabIndex = 15;
            this.lvwContacts.UseCompatibleStateImageBehavior = false;
            this.lvwContacts.View = System.Windows.Forms.View.Details;
            this.lvwContacts.SelectedIndexChanged += new System.EventHandler(this.lvwContacts_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "";
            this.columnHeader1.Width = 178;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Aluno.png");
            this.imageList1.Images.SetKeyName(1, "Professor.png");
            this.imageList1.Images.SetKeyName(2, "User(Perfil).png");
            // 
            // lblContacts
            // 
            this.lblContacts.AutoSize = true;
            this.lblContacts.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContacts.ForeColor = System.Drawing.Color.White;
            this.lblContacts.Location = new System.Drawing.Point(-4, 46);
            this.lblContacts.Name = "lblContacts";
            this.lblContacts.Size = new System.Drawing.Size(165, 32);
            this.lblContacts.TabIndex = 17;
            this.lblContacts.Text = "Contactos";
            // 
            // panelMessages
            // 
            this.panelMessages.BackColor = System.Drawing.Color.LightGray;
            this.panelMessages.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelMessages.Controls.Add(this.lvwMessages);
            this.panelMessages.Controls.Add(this.pctSendMessage);
            this.panelMessages.Controls.Add(this.txtMessage);
            this.panelMessages.Controls.Add(this.imageSelectedContact);
            this.panelMessages.Controls.Add(this.lblSelectedContact);
            this.panelMessages.Location = new System.Drawing.Point(224, 81);
            this.panelMessages.Name = "panelMessages";
            this.panelMessages.Size = new System.Drawing.Size(443, 254);
            this.panelMessages.TabIndex = 18;
            // 
            // lvwMessages
            // 
            this.lvwMessages.HideSelection = false;
            this.lvwMessages.Location = new System.Drawing.Point(4, 50);
            this.lvwMessages.Name = "lvwMessages";
            this.lvwMessages.Size = new System.Drawing.Size(432, 159);
            this.lvwMessages.SmallImageList = this.imageList2;
            this.lvwMessages.TabIndex = 24;
            this.lvwMessages.UseCompatibleStateImageBehavior = false;
            this.lvwMessages.View = System.Windows.Forms.View.List;
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "Aluno.png");
            this.imageList2.Images.SetKeyName(1, "Professor.png");
            this.imageList2.Images.SetKeyName(2, "User(Perfil).png");
            // 
            // pctSendMessage
            // 
            this.pctSendMessage.Enabled = false;
            this.pctSendMessage.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.EnviarMsg;
            this.pctSendMessage.Location = new System.Drawing.Point(401, 212);
            this.pctSendMessage.Name = "pctSendMessage";
            this.pctSendMessage.Size = new System.Drawing.Size(40, 40);
            this.pctSendMessage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctSendMessage.TabIndex = 23;
            this.pctSendMessage.TabStop = false;
            this.pctSendMessage.Click += new System.EventHandler(this.pctSendMessage_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMessage.Location = new System.Drawing.Point(3, 215);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(392, 32);
            this.txtMessage.TabIndex = 22;
            this.txtMessage.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // imageSelectedContact
            // 
            this.imageSelectedContact.Location = new System.Drawing.Point(3, 3);
            this.imageSelectedContact.Name = "imageSelectedContact";
            this.imageSelectedContact.Size = new System.Drawing.Size(40, 40);
            this.imageSelectedContact.TabIndex = 21;
            this.imageSelectedContact.TabStop = false;
            // 
            // lblSelectedContact
            // 
            this.lblSelectedContact.AutoSize = true;
            this.lblSelectedContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedContact.Location = new System.Drawing.Point(49, 13);
            this.lblSelectedContact.Name = "lblSelectedContact";
            this.lblSelectedContact.Size = new System.Drawing.Size(57, 20);
            this.lblSelectedContact.TabIndex = 20;
            this.lblSelectedContact.Text = "label1";
            // 
            // btnCloseForm
            // 
            this.btnCloseForm.BackColor = System.Drawing.Color.Transparent;
            this.btnCloseForm.FlatAppearance.BorderSize = 0;
            this.btnCloseForm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCloseForm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCloseForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloseForm.ForeColor = System.Drawing.Color.Transparent;
            this.btnCloseForm.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Fechar;
            this.btnCloseForm.Location = new System.Drawing.Point(636, 2);
            this.btnCloseForm.Name = "btnCloseForm";
            this.btnCloseForm.Size = new System.Drawing.Size(40, 40);
            this.btnCloseForm.TabIndex = 5;
            this.btnCloseForm.UseVisualStyleBackColor = false;
            this.btnCloseForm.Click += new System.EventHandler(this.btnCloseForm_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Ondas_Azuis;
            this.pictureBox1.Location = new System.Drawing.Point(-9, 219);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(696, 137);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.ForeColor = System.Drawing.Color.Transparent;
            this.btnProfile.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.User_Perfil_;
            this.btnProfile.Location = new System.Drawing.Point(2, 2);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(40, 40);
            this.btnProfile.TabIndex = 13;
            this.btnProfile.UseVisualStyleBackColor = false;
            // 
            // FormMessages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(677, 347);
            this.Controls.Add(this.btnCloseForm);
            this.Controls.Add(this.panelMessages);
            this.Controls.Add(this.lblContacts);
            this.Controls.Add(this.lvwContacts);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblProfileName);
            this.Controls.Add(this.btnProfile);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormMessages";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormMessages";
            this.Load += new System.EventHandler(this.FormMessages_Load);
            this.panelMessages.ResumeLayout(false);
            this.panelMessages.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctSendMessage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageSelectedContact)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProfileName;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.ListView lvwContacts;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblContacts;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel panelMessages;
        private System.Windows.Forms.Button btnCloseForm;
        private System.Windows.Forms.PictureBox imageSelectedContact;
        private System.Windows.Forms.Label lblSelectedContact;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.PictureBox pctSendMessage;
        private System.Windows.Forms.ListView lvwMessages;
        private System.Windows.Forms.ImageList imageList2;
    }
}