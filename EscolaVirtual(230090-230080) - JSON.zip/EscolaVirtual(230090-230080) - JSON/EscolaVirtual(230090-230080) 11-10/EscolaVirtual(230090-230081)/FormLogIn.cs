﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormLogIn : Form
    {

        public FormLogIn()
        {
            InitializeComponent();
        }

        private void btnCloseForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Verificação do Login para saber qual o nivel de hierarquia a ser acedido
        private void btnLogIn_Click(object sender, EventArgs e)
        {
            //faz a comparação do texto para saber se é identico a algum dos acessos dos Admins
            if (Program.AdminList.Any(p => txtUser.Text == p.GetLogin() && txtPassword.Text == p.GetPassword()))
            {
                MessageBox.Show("Bem vindo Admin!");
                FormAdmin adminform = new FormAdmin(Program.AdminList[0]);//Abre o Form do nivel de acesso de Admin e acede á lista de Admins
                adminform.ShowDialog();
                this.Close();
            }
            else
            {
                //faz a comparação do texto para saber se é identico a algum dos acessos dos Professores apos a verificação anterior
                if (Program.TeacherList.Any(p => txtUser.Text == p.GetLogin() && txtPassword.Text == p.GetPassword()))
                {
                    int useridx = Program.TeacherList.FindIndex(p => p.GetLogin() == txtUser.Text);

                    MessageBox.Show("Bem vindo Professor!");
                    FormTeacher teacherform = new FormTeacher(Program.TeacherList[useridx]);//Abre o Form do nivel de acesso de Professores e acede á lista de professores
                    teacherform.ShowDialog();
                    this.Close();
                }
                else
                {
                    //faz a comparação do texto para saber se é identico a algum dos acessos dos Alunos apos a verificação anterior
                    if (Program.StudentList.Any(p => txtUser.Text == p.GetLogin() && txtPassword.Text == p.GetPassword()))
                    {
                        int useridx = Program.StudentList.FindIndex(p => p.GetLogin() == txtUser.Text);

                        MessageBox.Show("Bem vindo Aluno!");
                        FormStudent studentform = new FormStudent(Program.StudentList[useridx]);//Abre o Form do nivel de acesso de Alunos e acede á lista de Alunos
                        studentform.ShowDialog();
                        this.Close();
                    }
                    //Se nenhum dos parametros anteriores for verificado invalida o Login e coloca as caixas de texto vazias e a caixa de texto da Password com os caracteres invisiveis
                    else
                    {
                        MessageBox.Show("Inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtUser.Text = "";
                        txtPassword.Text = "";
                        btnToggleVision2.BringToFront();
                        txtPassword.PasswordChar = '●';
                    }
                }
            }
        }

        //Os caracteres da Password deixam de estar "escondidos" apos clicar no botao associado
        private void btnToggleVision2_Click(object sender, EventArgs e)
        {
            btnToggleVision.BringToFront();
            txtPassword.PasswordChar = '\0';
        }

        //Deixa os caracteres da text box "escondidos" apos clicar no botao associado
        private void btnToggleVision_Click(object sender, EventArgs e)
        {
            btnToggleVision2.BringToFront();
            txtPassword.PasswordChar = '●';
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
