﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Text.Json;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace EscolaVirtual_230090_230081_
{
    internal static class Program
    {
        public static readonly JsonSerializerSettings JsonSettings = new JsonSerializerSettings
        {
            ContractResolver = new DefaultContractResolver
            {
                DefaultMembersSearchFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance
            }
        };

        public static List<Grade> GradesList { get; set; } = new List<Grade>();

        public static List<Subject> SubjectsList { get; set; } = new List<Subject>()
        {
            new Subject("Educação Física", "P005"),
            new Subject("Matemática", "P001"),
            new Subject("Música", "P002"),
            new Subject("Kizomba", "P003"),
            new Subject("Português", "P004")
        };

        public static List<Class> ClassesList { get; set; } = new List<Class>()
        {
            new Class("A", 6, "10º"),
            new Class("B", 7, "10º"),
            new Class("A", 6, "11º"),
            new Class("B", 7, "11º")
        };

        public static List<Year> YearsList { get; set; } = new List<Year>()
        {
            new Year("10º",
                new List<Class>()
                {
                    new Class("A", 6, "10º"),
                    new Class("B", 7, "10º")
                },
                new List<Subject>()
                {
                    new Subject("Educação Física", "P005"),
                    new Subject("Matemática", "P001"),
                    new Subject("Música", "P002"),
                    new Subject("Kizomba", "P003"),
                    new Subject("Português", "P004")
                }
            ),
            new Year("11º",
                new List<Class>()
                {
                    new Class("A", 6, "11º"),
                    new Class("B", 7, "11º")
                },
                new List<Subject>()
                {
                    new Subject("Educação Física", "P005"),
                    new Subject("Matemática", "P001"),
                    new Subject("Música", "P002"),
                    new Subject("Kizomba", "P003"),
                    new Subject("Português", "P004")
                }
            )
        };

        public static List<Admin> AdminList { get; set; } = new List<Admin>()
        {
            new Admin("Master", "Master123", "Master")
        };

        public static List<Teacher> TeacherList { get; set; } = new List<Teacher>()
        {
            new Teacher("414141414", "P001", "P001_", "Gonçalo Galvão", SubjectsList[1], ClassesList[0]),
            new Teacher("121465979", "P002", "P002_", "António Ferrão", SubjectsList[2], ClassesList[0]),
            new Teacher("486944253", "P003", "P003_", "Badoxa Tarraxo", SubjectsList[3], ClassesList[0]),
            new Teacher("676767676", "P004", "P004_", "Quim Barreiros", SubjectsList[4], ClassesList[1]),
            new Teacher("115885834", "P005", "P005_", "Guita Pimpolho", SubjectsList[0], ClassesList[1])
        };

        public static List<Student> StudentList { get; set; } = new List<Student>()
        {
            new Student("728693440", "A001", "A001_", "Carlos Jesus", ClassesList[0]),
            new Student("380344787", "A002", "A002_", "Jose Pereira", ClassesList[0]),
            new Student("707778661", "A003", "A003_", "Joaquim Lopes", ClassesList[0]),
            new Student("744484523", "A004", "A004_", "Maria Joaquina", ClassesList[0]),
            new Student("715894830", "A005", "A005_", "Joao Dias", ClassesList[0]),
            new Student("299268658", "A006", "A006_", "Cristiano Ronaldo", ClassesList[0]),
            new Student("397606721", "A007", "A007_", "Lionel Messi", ClassesList[1]),
            new Student("825997087", "A008", "A008_", "Georgina Lopez", ClassesList[1]),
            new Student("630768252", "A009", "A009_", "Maria Joaquina", ClassesList[1]),
            new Student("700231050", "A010", "A010_", "Maria Leal", ClassesList[1]),
            new Student("428942019", "A011", "A011_", "Miguel Luz", ClassesList[1]),
            new Student("182102792", "A012", "A012_", "Rodrigo Gomes", ClassesList[1]),
            new Student("912345678", "A013", "A013_", "André Silva", ClassesList[2]),
            new Student("923456789", "A014", "A014_", "Beatriz Costa", ClassesList[2]),
            new Student("934567890", "A015", "A015_", "Cláudia Ferreira", ClassesList[2]),
            new Student("945678901", "A016", "A016_", "Diogo Martins", ClassesList[2]),
            new Student("956789012", "A017", "A017_", "Eduarda Ramos", ClassesList[2]),
            new Student("967890123", "A018", "A018_", "Filipe Nogueira", ClassesList[2]),
            new Student("978901234", "A019", "A019_", "Gabriela Sousa", ClassesList[3]),
            new Student("989012345", "A020", "A020_", "Hugo Almeida", ClassesList[3]),
            new Student("990123456", "A021", "A021_", "Inês Carvalho", ClassesList[3]),
            new Student("901234567", "A022", "A022_", "Joana Rodrigues", ClassesList[3]),
            new Student("902345678", "A023", "A023_", "Luís Teixeira", ClassesList[3]),
            new Student("903456789", "A024", "A024_", "Marta Oliveira", ClassesList[3])
        };

        [STAThread]
        static void Main()
        {
            //Deserialize
            if (File.Exists("YearsList.json"))
            {
                YearsList.Clear();
                string jsonYearR = System.IO.File.ReadAllText("YearsList.json");
                YearsList = JsonConvert.DeserializeObject<List<Year>>(jsonYearR, JsonSettings);
            }

            if (File.Exists("StudentsList.json"))
            {
                StudentList.Clear();
                string jsonStudentR = System.IO.File.ReadAllText("StudentsList.json");
                StudentList = JsonConvert.DeserializeObject<List<Student>>(jsonStudentR, JsonSettings);
            }

            if (File.Exists("TeachersList.json"))
            {
                TeacherList.Clear();
                string jsonTeacherR = System.IO.File.ReadAllText("TeachersList.json");
                TeacherList = JsonConvert.DeserializeObject<List<Teacher>>(jsonTeacherR, JsonSettings);
            }

            if (File.Exists("GradesList.json"))
            {
                GradesList.Clear();
                string jsonGradeR = System.IO.File.ReadAllText("GradesList.json");
                GradesList = JsonConvert.DeserializeObject<List<Grade>>(jsonGradeR, JsonSettings);
            }

            //Serialize
            string jsonYear = JsonConvert.SerializeObject(YearsList, JsonSettings);
            System.IO.File.WriteAllText("YearsList.json", jsonYear);

            string jsonStudent = JsonConvert.SerializeObject(StudentList, JsonSettings);
            System.IO.File.WriteAllText("StudentsList.json", jsonStudent);

            string jsonTeacher = JsonConvert.SerializeObject(TeacherList, JsonSettings);
            System.IO.File.WriteAllText("TeachersList.json", jsonTeacher);

            string jsonGrade = JsonConvert.SerializeObject(GradesList, JsonSettings);
            System.IO.File.WriteAllText("GradesList.json", jsonGrade);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormLogIn());
        }
    }
}
