﻿namespace EscolaVirtual_230090_230081_
{
    partial class FormTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProfileName = new System.Windows.Forms.Label();
            this.lblMenu = new System.Windows.Forms.Label();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelMessages = new System.Windows.Forms.Panel();
            this.lblMessages = new System.Windows.Forms.Label();
            this.panelManagementPanels = new System.Windows.Forms.Panel();
            this.panelGrades = new System.Windows.Forms.Panel();
            this.lblGrades = new System.Windows.Forms.Label();
            this.btnGrades = new System.Windows.Forms.Button();
            this.btnMessages = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelGradesManagement = new System.Windows.Forms.Panel();
            this.lvwGrades = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnCreateGrade = new System.Windows.Forms.Button();
            this.panelMenu.SuspendLayout();
            this.panelMessages.SuspendLayout();
            this.panelManagementPanels.SuspendLayout();
            this.panelGrades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelGradesManagement.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblProfileName
            // 
            this.lblProfileName.AutoSize = true;
            this.lblProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfileName.Location = new System.Drawing.Point(49, 13);
            this.lblProfileName.Name = "lblProfileName";
            this.lblProfileName.Size = new System.Drawing.Size(57, 20);
            this.lblProfileName.TabIndex = 12;
            this.lblProfileName.Text = "label1";
            this.lblProfileName.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // lblMenu
            // 
            this.lblMenu.AutoSize = true;
            this.lblMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMenu.Location = new System.Drawing.Point(48, 70);
            this.lblMenu.Name = "lblMenu";
            this.lblMenu.Size = new System.Drawing.Size(53, 20);
            this.lblMenu.TabIndex = 20;
            this.lblMenu.Text = "Menu";
            this.lblMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelMenu.Controls.Add(this.panelGrades);
            this.panelMenu.Controls.Add(this.panelMessages);
            this.panelMenu.Enabled = false;
            this.panelMenu.ForeColor = System.Drawing.Color.Transparent;
            this.panelMenu.Location = new System.Drawing.Point(24, 107);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(198, 106);
            this.panelMenu.TabIndex = 21;
            // 
            // panelMessages
            // 
            this.panelMessages.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelMessages.Controls.Add(this.lblMessages);
            this.panelMessages.Controls.Add(this.btnMessages);
            this.panelMessages.Location = new System.Drawing.Point(2, 56);
            this.panelMessages.Name = "panelMessages";
            this.panelMessages.Size = new System.Drawing.Size(193, 47);
            this.panelMessages.TabIndex = 17;
            this.panelMessages.Click += new System.EventHandler(this.panelMessages_Click);
            // 
            // lblMessages
            // 
            this.lblMessages.AutoSize = true;
            this.lblMessages.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessages.ForeColor = System.Drawing.Color.Black;
            this.lblMessages.Location = new System.Drawing.Point(49, 12);
            this.lblMessages.Name = "lblMessages";
            this.lblMessages.Size = new System.Drawing.Size(101, 20);
            this.lblMessages.TabIndex = 13;
            this.lblMessages.Text = "Mensagens";
            this.lblMessages.Click += new System.EventHandler(this.panelMessages_Click);
            // 
            // panelManagementPanels
            // 
            this.panelManagementPanels.Controls.Add(this.panelGradesManagement);
            this.panelManagementPanels.Location = new System.Drawing.Point(261, 70);
            this.panelManagementPanels.Name = "panelManagementPanels";
            this.panelManagementPanels.Size = new System.Drawing.Size(491, 331);
            this.panelManagementPanels.TabIndex = 22;
            // 
            // panelGrades
            // 
            this.panelGrades.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelGrades.Controls.Add(this.lblGrades);
            this.panelGrades.Controls.Add(this.btnGrades);
            this.panelGrades.Location = new System.Drawing.Point(2, 3);
            this.panelGrades.Name = "panelGrades";
            this.panelGrades.Size = new System.Drawing.Size(193, 47);
            this.panelGrades.TabIndex = 17;
            this.panelGrades.Click += new System.EventHandler(this.btnGrades_Click);
            // 
            // lblGrades
            // 
            this.lblGrades.AutoSize = true;
            this.lblGrades.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrades.ForeColor = System.Drawing.Color.Black;
            this.lblGrades.Location = new System.Drawing.Point(49, 12);
            this.lblGrades.Name = "lblGrades";
            this.lblGrades.Size = new System.Drawing.Size(56, 20);
            this.lblGrades.TabIndex = 13;
            this.lblGrades.Text = "Notas";
            this.lblGrades.Click += new System.EventHandler(this.btnGrades_Click);
            // 
            // btnGrades
            // 
            this.btnGrades.BackColor = System.Drawing.Color.Transparent;
            this.btnGrades.FlatAppearance.BorderSize = 0;
            this.btnGrades.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGrades.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGrades.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGrades.ForeColor = System.Drawing.Color.Transparent;
            this.btnGrades.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Notas;
            this.btnGrades.Location = new System.Drawing.Point(3, 3);
            this.btnGrades.Name = "btnGrades";
            this.btnGrades.Size = new System.Drawing.Size(40, 40);
            this.btnGrades.TabIndex = 11;
            this.btnGrades.UseVisualStyleBackColor = false;
            this.btnGrades.Click += new System.EventHandler(this.btnGrades_Click);
            // 
            // btnMessages
            // 
            this.btnMessages.BackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatAppearance.BorderSize = 0;
            this.btnMessages.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMessages.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMessages.ForeColor = System.Drawing.Color.Transparent;
            this.btnMessages.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Mensagens;
            this.btnMessages.Location = new System.Drawing.Point(3, 3);
            this.btnMessages.Name = "btnMessages";
            this.btnMessages.Size = new System.Drawing.Size(40, 40);
            this.btnMessages.TabIndex = 11;
            this.btnMessages.UseVisualStyleBackColor = false;
            this.btnMessages.Click += new System.EventHandler(this.panelMessages_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.ForeColor = System.Drawing.Color.Transparent;
            this.btnMenu.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Menu;
            this.btnMenu.Location = new System.Drawing.Point(2, 61);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(40, 40);
            this.btnMenu.TabIndex = 19;
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.ForeColor = System.Drawing.Color.Transparent;
            this.btnProfile.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Professor;
            this.btnProfile.Location = new System.Drawing.Point(3, 3);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(40, 40);
            this.btnProfile.TabIndex = 11;
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.Color.Transparent;
            this.btnMinimize.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Minimize;
            this.btnMinimize.Location = new System.Drawing.Point(712, 3);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(40, 40);
            this.btnMinimize.TabIndex = 10;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogOut.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.LogOut1;
            this.btnLogOut.Location = new System.Drawing.Point(758, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(40, 40);
            this.btnLogOut.TabIndex = 9;
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::EscolaVirtual_230090_230081_.Properties.Resources.Ondas_Azuis;
            this.pictureBox1.Location = new System.Drawing.Point(-9, 219);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(821, 250);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // panelGradesManagement
            // 
            this.panelGradesManagement.BackColor = System.Drawing.Color.Silver;
            this.panelGradesManagement.Controls.Add(this.btnCreateGrade);
            this.panelGradesManagement.Controls.Add(this.lvwGrades);
            this.panelGradesManagement.Location = new System.Drawing.Point(0, 0);
            this.panelGradesManagement.Name = "panelGradesManagement";
            this.panelGradesManagement.Size = new System.Drawing.Size(491, 331);
            this.panelGradesManagement.TabIndex = 0;
            // 
            // lvwGrades
            // 
            this.lvwGrades.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvwGrades.HideSelection = false;
            this.lvwGrades.Location = new System.Drawing.Point(14, 16);
            this.lvwGrades.Name = "lvwGrades";
            this.lvwGrades.Size = new System.Drawing.Size(462, 279);
            this.lvwGrades.TabIndex = 0;
            this.lvwGrades.UseCompatibleStateImageBehavior = false;
            this.lvwGrades.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Aluno";
            this.columnHeader1.Width = 115;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Ano/Turma";
            this.columnHeader2.Width = 79;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Disciplina";
            this.columnHeader3.Width = 126;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Nota";
            this.columnHeader4.Width = 137;
            // 
            // btnCreateGrade
            // 
            this.btnCreateGrade.Location = new System.Drawing.Point(185, 301);
            this.btnCreateGrade.Name = "btnCreateGrade";
            this.btnCreateGrade.Size = new System.Drawing.Size(125, 23);
            this.btnCreateGrade.TabIndex = 1;
            this.btnCreateGrade.Text = "Dar nota";
            this.btnCreateGrade.UseVisualStyleBackColor = true;
            this.btnCreateGrade.Click += new System.EventHandler(this.btnCreateGrade_Click);
            // 
            // FormTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelManagementPanels);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.lblMenu);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.lblProfileName);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnMinimize);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormTeacher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormTeacher";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormTeacher_FormClosed);
            this.Load += new System.EventHandler(this.FormTeacher_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelMessages.ResumeLayout(false);
            this.panelMessages.PerformLayout();
            this.panelManagementPanels.ResumeLayout(false);
            this.panelGrades.ResumeLayout(false);
            this.panelGrades.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelGradesManagement.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label lblProfileName;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Label lblMenu;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelMessages;
        private System.Windows.Forms.Label lblMessages;
        private System.Windows.Forms.Button btnMessages;
        private System.Windows.Forms.Panel panelManagementPanels;
        private System.Windows.Forms.Panel panelGrades;
        private System.Windows.Forms.Label lblGrades;
        private System.Windows.Forms.Button btnGrades;
        private System.Windows.Forms.Panel panelGradesManagement;
        private System.Windows.Forms.ListView lvwGrades;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btnCreateGrade;
    }
}