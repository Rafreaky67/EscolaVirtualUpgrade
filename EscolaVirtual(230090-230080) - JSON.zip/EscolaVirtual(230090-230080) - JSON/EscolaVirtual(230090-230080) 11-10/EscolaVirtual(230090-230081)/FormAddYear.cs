﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormAddYear : Form
    {
        public FormAddYear()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cbbYears.SelectedIndex != -1)
            {
                bool proc = Program.YearsList.Any(item => item.GetYear() == cbbYears.SelectedItem.ToString());

                if (proc)
                {
                    MessageBox.Show("Esse ano já existe.\n\nNão podem existir anos repetidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cbbYears.SelectedIndex = -1;
                }
                else
                {
                    Year newYear = new Year(cbbYears.SelectedItem.ToString(), new List<Class>(), new List<Subject>());


                    int ExtractNumber(string text)
                    {
                        string digits = new string(text.Where(char.IsDigit).ToArray());
                        return int.TryParse(digits, out int result) ? result : int.MaxValue;
                    }

                    int newYearValue = ExtractNumber(cbbYears.SelectedItem.ToString());


                    int index = Program.YearsList.FindIndex(y => ExtractNumber(y.GetYear()) > newYearValue);

                    if (index >= 0)
                        Program.YearsList.Insert(index, newYear);
                    else
                        Program.YearsList.Add(newYear);

                    System.IO.File.WriteAllText("YearsList.json", JsonSettings.Serialize(Program.YearsList)); 
                    MessageBox.Show("Ano adicionado em ordem.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Tem que selecionar um ano.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}


