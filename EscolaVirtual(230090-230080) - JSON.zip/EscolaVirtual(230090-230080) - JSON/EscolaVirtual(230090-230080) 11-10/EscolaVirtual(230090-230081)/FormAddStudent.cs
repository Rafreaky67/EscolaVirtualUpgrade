﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormAddStudent : Form
    {
        public FormAddStudent()
        {
            InitializeComponent();
        }

        private void FormAddStudent_Load(object sender, EventArgs e)
        {
            foreach (Year itemY in Program.YearsList)
            { 
                TreeNode parent = new TreeNode();
                parent.Text = itemY.GetYear();
                tvwClasses.Nodes.Add(parent);
                foreach (Class itemC in itemY.GetClasses())
                { 
                    TreeNode classnode = new TreeNode();
                    classnode.Text = itemC.GetAcronym();
                    parent.Nodes.Add(classnode);
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && txtNIF.Text != "" && txtLogin.Text != "" && txtPassword.Text != "")
            {
                if (txtNIF.Text.Length != 9)
                    MessageBox.Show("NIF inválido.\n\nNIF tem que ter 9 dígitos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    foreach (Teacher itemT in Program.TeacherList)
                    {
                        foreach (Student itemS in Program.StudentList)
                        {
                            if (txtNIF.Text == itemT.GetNIF() || txtNIF.Text == itemS.GetNIF())
                            {
                                MessageBox.Show("Já existe um utilizador com o mesmo NIF.\n\nNão podem existir NIF iguais.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }

                    foreach (Teacher itemT in Program.TeacherList)
                    {
                        foreach (Student itemS in Program.StudentList)
                        {
                            if (txtLogin.Text == itemT.GetLogin() || txtLogin.Text == itemS.GetLogin())
                            {
                                MessageBox.Show("Já existe um utilizador com o mesmo Login.\n\nNão podem existir logins iguais.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }

                    if (txtLogin.Text.Length == 4)
                    {
                        if (txtLogin.Text.ToUpper()[0] != 'A' || !(txtLogin.Text[1] >= '0' && txtLogin.Text[1] <= '9') || !(txtLogin.Text[2] >= '0' && txtLogin.Text[2] <= '9') || !(txtLogin.Text[3] >= '0' && txtLogin.Text[3] <= '9'))
                        {
                            MessageBox.Show("Login inválido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Login inválido.\n\nO Login não cumpre as normas.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                bool proc1 = false;
                string year = "";
                string class_ = "";

                foreach (TreeNode itemP in tvwClasses.Nodes)
                {
                   
                    foreach (TreeNode itemTN in itemP.Nodes)
                    {
                        if (itemTN.IsSelected == true)
                        {
                            year = itemP.Text;
                            class_ = itemTN.Text;
                            proc1 = true;
                            break;
                        }
                    }
                    if (proc1 == true)
                        break;
                }

                if (proc1 == false)
                    MessageBox.Show("Tem que selecionar uma turma.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    Student newstudent = new Student(txtNIF.Text, txtLogin.Text, txtPassword.Text, txtName.Text, Program.ClassesList.First(p => p.GetYear() == year && p.GetAcronym() == class_));
                    Program.StudentList.Add(newstudent);
                    System.IO.File.WriteAllText("StudentsList.json", JsonSettings.Serialize(Program.StudentList));
                    MessageBox.Show("O aluno '" + newstudent.GetName() + "' foi adicionado.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Os campos (Nome, NIF, Login, Password e Turma(tem que selecionar)) têm que estar preenchidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //este evento vai impedir de escrever números e outros tipos de caracteres que não sejam letras e espaços no campo do nome
        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;

            if (!char.IsLetter(c) && c != 8 && c != 46 && c != 32)
                e.Handled = true;
        }

        //este evento vai impedir de escrever letras e outros tipos de caracteres que não sejam números e espaços no campo do NIF
        private void txtNIF_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;

            if (!char.IsDigit(c) && c != 8 && c != 46)
                e.Handled = true;
        }
    }
}