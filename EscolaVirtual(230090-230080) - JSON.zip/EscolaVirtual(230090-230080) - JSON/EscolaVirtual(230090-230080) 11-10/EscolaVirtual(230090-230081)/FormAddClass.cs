﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormAddClass : Form
    {
        public FormAddClass()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cbbYears.SelectedIndex != -1 && cbbClasses.SelectedIndex != -1)
            {
                bool proc = false;

                foreach (Year itemY in Program.YearsList)
                {
                    foreach (Class itemC in itemY.GetClasses())
                    {
                        proc = itemY.GetYear() == cbbYears.SelectedItem.ToString() &&
                               itemC.GetAcronym() == cbbClasses.SelectedItem.ToString();
                        
                        if (proc) { break; }
                    }
                    if(proc) { break; }
                }

                if (proc)
                {
                    MessageBox.Show("Essa turma já existe nesse ano.\n\nNão podem existir turmas repetidas no mesmo ano.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cbbYears.SelectedIndex = -1;
                }
                else
                {
                    Year year = Program.YearsList.Find(p => p.GetYear() == cbbYears.SelectedItem.ToString());
                    Class newclass = new Class(cbbClasses.SelectedItem.ToString(), Convert.ToInt16(numericUpDown1.Value), year.GetYear());
                    year.AddClass(newclass);
                    System.IO.File.WriteAllText("YearsList.json", JsonSettings.Serialize(Program.YearsList));
                    MessageBox.Show("Turma adicionada.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            else
            {
                if (cbbYears.SelectedIndex == -1)
                    MessageBox.Show("Tem que selecionar um ano.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Tem que selecionar uma turma.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddClass_Load(object sender, EventArgs e)
        {
            foreach (Year itemY in Program.YearsList)
            { 
                cbbYears.Items.Add(itemY.GetYear());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
