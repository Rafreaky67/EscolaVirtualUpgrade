﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormAddSubject : Form
    {
        public FormAddSubject()
        {
            InitializeComponent();
        }

        private void FormAddSubject_Load(object sender, EventArgs e)
        {
            foreach (Year itemY in Program.YearsList)
            {
                cbbYears.Items.Add(itemY.GetYear());
            }

            foreach (Subject itemS in Program.SubjectsList)
            {
                cbbSubjects.Items.Add(itemS.GetName());
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cbbYears.SelectedIndex != -1 && cbbSubjects.SelectedIndex != -1)
            {
                foreach (Year itemY in Program.YearsList)
                {
                    if (itemY.GetYear() == cbbYears.SelectedItem.ToString())
                    {
                        if (itemY.GetSubjects().Count > 0)
                        {
                            if (itemY.GetSubjects().Any(p => p.GetName() == cbbSubjects.SelectedItem.ToString()))
                            {
                                MessageBox.Show("Essa disciplina já existe nesse ano.\n\nNão podem existir disciplinas repetidas no mesmo ano.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                cbbSubjects.SelectedIndex = -1;
                            }
                            else
                            {
                                foreach (Subject itemS in Program.SubjectsList)
                                {
                                    if (itemS.GetName() == cbbSubjects.SelectedItem.ToString())
                                    {
                                        Subject newsubject = new Subject(cbbSubjects.SelectedItem.ToString(), itemS.GetTeacher());
                                        Year year = Program.YearsList.Find(p => p.GetYear() == cbbYears.SelectedItem.ToString());
                                        year.AddSubject(newsubject);
                                        System.IO.File.WriteAllText("YearsList.json", JsonSettings.Serialize(Program.YearsList));
                                        MessageBox.Show("Disciplina adicionada.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        break;
                                    }
                                }
                                this.Close();
                            }
                        }
                        else
                        {
                            foreach (Subject itemS in Program.SubjectsList)
                            {
                                if (itemS.GetName() == cbbSubjects.SelectedItem.ToString())
                                {
                                    Subject newsubject = new Subject(cbbSubjects.SelectedItem.ToString(), itemS.GetTeacher());
                                    Year year = Program.YearsList.Find(p => p.GetYear() == cbbYears.SelectedItem.ToString());
                                    year.AddSubject(newsubject);
                                    JsonSettings.Serialize(Program.YearsList);
                                    MessageBox.Show("Disciplina adicionada.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    break;
                                }
                            }
                            this.Close();
                        }
                    }
                }
            }
            else
            {
                if (cbbYears.SelectedIndex == -1)
                    MessageBox.Show("Tem que selecionar um ano.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Tem que selecionar uma disciplina.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
