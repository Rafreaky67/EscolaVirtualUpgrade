﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual_230090_230081_
{
    public partial class FormProfile : Form
    {
        User logedinuser;

        public FormProfile(User user)
        {
            InitializeComponent();
            logedinuser = user;
        }

        private void FormProfile_Load(object sender, EventArgs e)
        {
            lblProfileName.Text = logedinuser.GetName();
            txtLogin.Text = logedinuser.GetLogin();
            txtPassword.Text = logedinuser.GetPassword();
            
        }

        private void btnCloseForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnChangeLogIn_Click(object sender, EventArgs e)
        {
            foreach (Teacher itemT in Program.TeacherList)
            {
                foreach (Student itemS in Program.StudentList)
                {
                    if (txtLogin.Text == itemT.GetLogin() || txtLogin.Text == itemS.GetLogin())
                    {
                        MessageBox.Show("Já existe um utilizador com o mesmo Login.\n\nPeça outro Login.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            logedinuser.SetLogin(txtLogin.Text);
            System.IO.File.WriteAllText("StudentsList.json", JsonSettings.Serialize(Program.StudentList));
            System.IO.File.WriteAllText("TeacherList.json", JsonSettings.Serialize(Program.TeacherList));
            MessageBox.Show("Login do utilizador '" + logedinuser.GetName() + "' alterado com sucsesso.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            logedinuser.SetPassword(txtPassword.Text);
            System.IO.File.WriteAllText("StudentsList.json", JsonSettings.Serialize(Program.StudentList));
            System.IO.File.WriteAllText("TeacherList.json", JsonSettings.Serialize(Program.TeacherList));
            MessageBox.Show("Password do utilizador '" + logedinuser.GetName() + "' alterado com sucsesso.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtLogin_TextChanged(object sender, EventArgs e)
        {
            if (txtLogin.Text != logedinuser.GetLogin())
                btnChangeLogIn.Enabled = true;
            else
                btnChangeLogIn.Enabled = false;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if(txtPassword.Text != logedinuser.GetPassword())
                btnChangePassword.Enabled = true;
            else
                btnChangePassword.Enabled = false;
        }
    }
}
